package edu.gsu.mllab.androidclient.activity;

import android.app.Activity;
import android.app.Fragment;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.v4.content.ContextCompat;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import edu.gsu.mllab.androidclient.R;
import edu.gsu.mllab.androidclient.bitmap.BitmapInput;
import edu.gsu.mllab.androidclient.bitmap.BitmapUtils;

public class CustomShapeActivity extends Activity {

    private CustomShapeFragment mCustomShapeFragment;
    private Bitmap cameraBitmap;
    private Bitmap originalBitmap;

    //keep track of camera capture intent
    final int CAMERA_CAPTURE = 1;
    //keep track of cropping intent
    final int PIC_CROP = 2;
    //captured picture uri
    private Uri picUri;

    private RadioGroup radioGroup1;
    private RadioGroup radioGroup2;

    int chkId1;
    int chkId2;
    int realCheck;

    //@Bind(R.id.imageview)
    //ImageView mImageView;


    RadioButton radioLine;
    RadioButton radioSmoothLine;
    RadioButton radioRectangle;
    RadioButton radioSquare;
    RadioButton radioCircle;
    RadioButton radioTriangle;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout_customshape_activity);
        radioGroup1 = (RadioGroup) findViewById(R.id.radioGroup1);
        radioGroup2 = (RadioGroup) findViewById(R.id.radioGroup2);

        radioLine = (RadioButton) findViewById(R.id.radioLine);
        radioSmoothLine = (RadioButton) findViewById(R.id.radioSmoothline);
        radioRectangle = (RadioButton) findViewById(R.id.radioRectangle);
        radioSquare = (RadioButton) findViewById(R.id.radioSquare);
        radioCircle = (RadioButton) findViewById(R.id.radioCircle);
        radioTriangle = (RadioButton) findViewById(R.id.radioTriangle);

        chkId1 = radioGroup1.getCheckedRadioButtonId();
        chkId2 = radioGroup2.getCheckedRadioButtonId();
        realCheck = chkId1 == -1 ? chkId2 : chkId1;

        if (savedInstanceState == null) {
            mCustomShapeFragment = new CustomShapeFragment();
            getFragmentManager().beginTransaction()
                    .add(R.id.container, mCustomShapeFragment)
                    .commit();
        }
        setStatusBarCol();

        radioGroup1.clearCheck(); // this is so we can start fresh, with no selection on both RadioGroups
        radioGroup2.clearCheck();
        // Checked change Listener for RadioGroup 1&2
        radioGroup1.setOnCheckedChangeListener(listener1);
        radioGroup2.setOnCheckedChangeListener(listener2);

    }

    private RadioGroup.OnCheckedChangeListener listener1 = new RadioGroup.OnCheckedChangeListener() {

        @Override
        public void onCheckedChanged(RadioGroup group, int checkedId) {
            if (checkedId != -1) {
                radioGroup2.setOnCheckedChangeListener(null); // remove the listener before clearing so we don't throw that stackoverflow exception(like Vladimir Volodin pointed out)
                radioGroup2.clearCheck(); // clear the second RadioGroup!
                radioGroup2.setOnCheckedChangeListener(listener2); //reset the listener
                //Log.e("XXX2", "do the work");
                mCustomShapeFragment.initializeCustomDrawing(checkedId);
                switch (checkedId) {
                    case R.id.radioLine:
                        Toast.makeText(getApplicationContext(), "Line RadioButton checked", Toast.LENGTH_SHORT).show();
                        break;
                    case R.id.radioSmoothline:
                        //uncheckRadios(R.id.radioGroup1, radioSmoothLine);
                        Toast.makeText(getApplicationContext(), "Smoothline RadioButton checked", Toast.LENGTH_SHORT).show();
                        break;
                    case R.id.radioRectangle:
                        //uncheckRadios(R.id.radioGroup1, radioRectangle);
                        Toast.makeText(getApplicationContext(), "Rectangle RadioButton checked", Toast.LENGTH_SHORT).show();
                        break;
                    default:
                        break;
                }
            }
        }
    };

    private RadioGroup.OnCheckedChangeListener listener2 = new RadioGroup.OnCheckedChangeListener() {

        @Override
        public void onCheckedChanged(RadioGroup group, int checkedId) {
            if (checkedId != -1) {
                radioGroup1.setOnCheckedChangeListener(null);
                radioGroup1.clearCheck();
                radioGroup1.setOnCheckedChangeListener(listener1);
                //radioGroup1.e("XXX2", "do the work");
                mCustomShapeFragment.initializeCustomDrawing(checkedId);
                switch (checkedId) {
                    case R.id.radioSquare:
                        //uncheckRadios(R.id.radioGroup2, radioSquare);
                        Toast.makeText(getApplicationContext(), "Square RadioButton checked", Toast.LENGTH_SHORT).show();
                        break;
                    case R.id.radioCircle:
                        //uncheckRadios(R.id.radioGroup2, radioCircle);
                        Toast.makeText(getApplicationContext(), "Circle RadioButton checked", Toast.LENGTH_SHORT).show();
                        break;
                    case R.id.radioTriangle:
                        //uncheckRadios(R.id.radioGroup2, radioTriangle);
                        Toast.makeText(getApplicationContext(), "Triangle RadioButton checked", Toast.LENGTH_SHORT).show();
                        break;
                    default:
                        break;
                }
            }
        }
    };

    public void setStatusBarCol() {
        Window window = getWindow();

    // clear FLAG_TRANSLUCENT_STATUS flag:
        window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);

    // add FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS flag to the window
        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);

    // finally change the color
        window.setStatusBarColor(ContextCompat.getColor(this,R.color.primary_dark));
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.drawing_options_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.

        return super.onOptionsItemSelected(item);
    }

    public void refreshBitmap(View view) {
/*        radioGroup1.clearCheck();
        radioGroup2.clearCheck();
        Bitmap bitmap = ((BitmapDrawable)mCustomShapeFragment.customImage.getDrawable()).getBitmap();
        Fragment currentFragment = mCustomShapeFragment;
        if (currentFragment instanceof CustomShapeFragment ) {
            if(bitmap.sameAs(cameraBitmap)){
                mCustomShapeFragment.customImage.setImageBitmap(cameraBitmap);
                mCustomShapeFragment.customImage.invalidate();
                Toast.makeText(this, "cameraBitmap = "+cameraBitmap,Toast.LENGTH_LONG).show();
            } else {
                FragmentTransaction fragTransaction =   getFragmentManager().beginTransaction();
                fragTransaction.detach(currentFragment);
                fragTransaction.attach(currentFragment);
                fragTransaction.commit();
            }
            }
  */  }

    public void loadGalleryData(View view){
        //Toast.makeText(this, "UNDO",Toast.LENGTH_LONG).show();
        Fragment currentFragment = mCustomShapeFragment;
        if (currentFragment instanceof CustomShapeFragment) {
            //((CustomShapeFragment) currentFragment).customImage.setImageURI(picUri);

            }
    }

    public void saveDrawing(View view) {
        takeScreenshot();
    }

    public Bitmap takeScreenshot() {
        View rootView = mCustomShapeFragment.getView();
        rootView.setDrawingCacheEnabled(true);
        //return rootView.getDrawingCache();
        Bitmap bitmap = rootView.getDrawingCache();
        BitmapInput bitmapInput = new BitmapInput("Some bitmap info", bitmap);
        BitmapUtils.saveBitmap(bitmapInput, null);

        return bitmap;
    }

    public void startCamera(View view) {
        try {
            //use standard intent to capture an image
            Intent captureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            //we will handle the returned data in onActivityResult
            startActivityForResult(captureIntent, CAMERA_CAPTURE);
        }catch(ActivityNotFoundException anfe){
            //display an error message
            String errorMessage = "Whoops - your device doesn't support capturing images!";
            Toast toast = Toast.makeText(this, errorMessage, Toast.LENGTH_SHORT);
            toast.show();
        }
    }

    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (resultCode == RESULT_OK) {
        //user is returning from capturing an image using the camera
            if(requestCode == CAMERA_CAPTURE){
        //get the Uri for the captured image
                //picUri = data.getData();
                //Toast toast = Toast.makeText(this, picUri+"", Toast.LENGTH_SHORT);
                //toast.show();
                //get the returned data
                Bundle extras = data.getExtras();
                //get the bitmap
                cameraBitmap = extras.getParcelable("data");
                //Toast toast1 = Toast.makeText(this, "The Pic= "+cameraBitmap, Toast.LENGTH_SHORT);
                //toast1.show();
                if (mCustomShapeFragment != null){
               //     mCustomShapeFragment.customImage.setImageBitmap(cameraBitmap);
                }
            }
        }
    }

}
