package edu.gsu.mllab.androidclient.data.model;

import android.util.Log;

import java.util.List;

import edu.gsu.mllab.androidclient.view.recyclerView.base.root.ParentListItem;

public class Category implements ParentListItem {
    private String categoryName;
    private List<SubCategory> subCategories;
    boolean exapnded = false;
    int subcategoriesCount;
    boolean collapsed = false;
    private String TAG = Category.class.getSimpleName();

    public Category(String name, List<SubCategory> subCategories) {
        super();
        categoryName = name;
        this.subCategories = subCategories;
    }

    public String getName() {
        return categoryName;
    }

    @Override
    public List<?> getChildItemList() {
        return subCategories;
    }

    @Override
    public boolean isInitiallyExpanded() {
        return false;
    }


    public boolean isExapnded() {
        return exapnded;
    }

    public void setExapnded(boolean exapnded) {
        this.exapnded = exapnded;
    }

    public int getSubcategoriesCount() {
        subcategoriesCount = subCategories.size();
        return subcategoriesCount;
    }

    public boolean isCollapsed() {
        return collapsed;
    }

    public void setCollapsed(boolean collapsed) {
        this.collapsed = collapsed;
    }

    public SubCategory getSubcategoryByName(String subCategoryName){
        for (SubCategory subCategory : subCategories){
            Log.e(TAG+" Current Subcategory = ", subCategory.getName());
            if (subCategory.getName().equalsIgnoreCase(subCategoryName)){
                return subCategory;
            }
        }
        return null;
    }
}
