package edu.gsu.mllab.androidclient.activity.groups.projects.sample;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import java.util.List;

import edu.gsu.mllab.androidclient.R;
import edu.gsu.mllab.androidclient.data.model.Category;
import edu.gsu.mllab.androidclient.data.model.SubCategory;
import edu.gsu.mllab.androidclient.view.recyclerView.base.root.ExpandableRecyclerAdapter;
import edu.gsu.mllab.androidclient.view.recyclerView.base.root.ParentListItem;

public class SampleAdapter extends ExpandableRecyclerAdapter<SampleCategoryViewHolder, SampleSubCategoryViewHolder> {

    private LayoutInflater mInflator;
    private View subcategoryView;
    private View categoryView;
    private SubCategory subcategory;
    private Category category;

    private SampleDashboardActivity activity;

    public SampleAdapter(Context context, List<? extends ParentListItem> parentItemList) {
        super(parentItemList);
        mInflator = LayoutInflater.from(context);
        this.activity = (SampleDashboardActivity) context;
    }

    @Override
    public SampleCategoryViewHolder onCreateParentViewHolder(ViewGroup parentViewGroup) {
        //This is category layout in master view of groups activity
        categoryView = mInflator.inflate(R.layout.sample_category_view, parentViewGroup, false);
        return new SampleCategoryViewHolder(categoryView);
    }

    @Override
    public SampleSubCategoryViewHolder onCreateChildViewHolder(ViewGroup childViewGroup) {
        //This is the child view in master view of groups activity
        subcategoryView = mInflator.inflate(R.layout.sample_subcategory_view, childViewGroup, false);
        return new SampleSubCategoryViewHolder(subcategoryView);
    }

    @Override
    public void onBindParentViewHolder(SampleCategoryViewHolder categoryViewHolder,final int position, ParentListItem parentListItem) {
        category = (Category) parentListItem;
        categoryViewHolder.bind(category);
    }

    @Override
    public void onBindChildViewHolder(final SampleSubCategoryViewHolder subCategoryViewHolder, final int position, Object childListItem) {
        subcategory = (SubCategory) childListItem;
        subCategoryViewHolder.bind(subcategory);

        subCategoryViewHolder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String label = subCategoryViewHolder.getSubcategoryLabelView().getText().toString();
                SubCategory subCategory = activity.getCurrentCategory().getSubcategoryByName(label);
                //pass this info to group category
                activity.setCurrentSubCategory(subCategory.getName());
                //TODO: At times, We may face problem in getting the true position of nested recycler, Fix it when everything else is fixed.


                Toast.makeText(activity, subCategory.getName(), Toast.LENGTH_SHORT).show();

            }
        });
    }

}
