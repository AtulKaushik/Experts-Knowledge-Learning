package edu.gsu.mllab.androidclient.events;

//import com.mllab.androidclient.ServerResponse;

/**
 * Created by Theodhor Pandeli on 2/11/2016.
 */
public class ServerEvent<T> {
    //private ServerResponse serverResponse;
    private T serverResponse;

    public ServerEvent(T serverResponse) {
        this.serverResponse = serverResponse;
    }

    public T getServerResponse() {
        return serverResponse;
    }

    public void setServerResponse(T serverResponse) {
        this.serverResponse = serverResponse;
    }

}
