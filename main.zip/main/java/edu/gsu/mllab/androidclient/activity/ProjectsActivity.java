package edu.gsu.mllab.androidclient.activity;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import edu.gsu.mllab.androidclient.R;

public class ProjectsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_projects);

        //Intent intent = new Intent(this, LoginActivity.class);
        //startActivity(intent);
    }

}
