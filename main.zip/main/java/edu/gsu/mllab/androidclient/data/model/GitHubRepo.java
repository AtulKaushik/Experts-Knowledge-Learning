package edu.gsu.mllab.androidclient.data.model;

/**
 * Created by mllab on 1/16/18.
 */

public class GitHubRepo {
    private int id;
    private String name;

    public GitHubRepo() {
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }
}