package edu.gsu.mllab.androidclient.bitmap;

import android.graphics.Bitmap;

public class BitmapResult {

    private final Bitmap bitmap;
    private final BitmapState state;

    private BitmapResult(Bitmap bitmap, BitmapState state) {
        this.bitmap = bitmap;
        this.state = state;
    }

    public Bitmap getBitmap() {
        return bitmap;
    }

    public BitmapState getState() {
        return state;
    }

    static BitmapResult success(Bitmap bitmap) {
        return new BitmapResult(bitmap, BitmapState.SUCCESS);
    }

    static BitmapResult error() {
        return new BitmapResult(null, BitmapState.ERROR);
    }

}
