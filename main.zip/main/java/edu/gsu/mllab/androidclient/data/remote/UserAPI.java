package edu.gsu.mllab.androidclient.data.remote;

import java.util.List;

import edu.gsu.mllab.androidclient.data.model.GitHubRepo;
import edu.gsu.mllab.androidclient.data.model.Group;
import edu.gsu.mllab.androidclient.data.model.User;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.Headers;
import retrofit2.http.POST;
import retrofit2.http.Path;

/**
 * Created by mllab on 1/16/18.
 */

/**
 * Client interface for users apis
 */
public interface UserAPI {
    @GET("/users/{id}/")
    Call<User> getUserById(@Path("id") String id);

    //@GET("/users/?format=json")
    @GET("/users/")
    Call<List<User>> getUsers();

    //@FormUrlEncoded
    //@Headers("Content-Type: application/json")
    //@POST("/users")
    // Fix this , it may be wrong
    Call<User> addUser(@Body User user);

    @POST("/users/")
    Call<User> createUser(@Body User user);
}