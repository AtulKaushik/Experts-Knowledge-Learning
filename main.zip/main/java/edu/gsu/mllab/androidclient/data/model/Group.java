package edu.gsu.mllab.androidclient.data.model;

/**
 * Created by mllab on 1/18/18.
 */

public class Group {

    private String name;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

}
