package edu.gsu.mllab.androidclient.activity.groups;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import java.util.Arrays;
import java.util.List;

import edu.gsu.mllab.androidclient.R;
import edu.gsu.mllab.androidclient.activity.groups.projects.brain.BrainDashboardActivity;
import edu.gsu.mllab.androidclient.activity.groups.projects.sample.SampleDashboardActivity;
import edu.gsu.mllab.androidclient.activity.groups.projects.solar.SolarDashboardActivity;
import edu.gsu.mllab.androidclient.data.model.Category;
import edu.gsu.mllab.androidclient.data.model.SubCategory;
import edu.gsu.mllab.androidclient.view.recyclerView.base.root.ExpandableRecyclerAdapter;

public class GroupsActivity extends AppCompatActivity {

    private GroupAdapter mAdapter;
    private RecyclerView mRecyclerView;
   private List<Category> mCategories;
    private Category mCurrentCategory;
    private String mCurrentSubcategory;
    private View mfragmentContainer;

    public Button btnGetItNow;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(null);
        setContentView(R.layout.activity_groups);

        Toolbar toolbar = (Toolbar) findViewById(R.id.groups_toolbar);
        setSupportActionBar(toolbar);
        toolbar.setTitle("Dashboard : Groups & Projects");

        mCategories = getCategories();

        mRecyclerView = findViewById(R.id.groups_master_detail_recyclerview);
        btnGetItNow =findViewById(R.id.btn_get_now);
        mfragmentContainer = findViewById(R.id.project_detail_container);

        btnGetItNow.getBackground().setAlpha(210);

        mAdapter = new GroupAdapter(this, mCategories);

        mAdapter.setExpandCollapseListener(new ExpandableRecyclerAdapter.ExpandCollapseListener() {
            @Override
            public void onListItemExpanded(int position) {
                Category expandedCategory = mCategories.get(position);
                //String group_position = "Selected Group Position :"+position;
                //Toast.makeText(GroupsActivity.this,group_position , Toast.LENGTH_LONG).show();

                mCurrentCategory = mCategories.get(position);

                expandedCategory.setExapnded(true);

                String toastMsg = getResources().getString(R.string.expanded, mCurrentCategory.getName());
                //Toast.makeText(GroupsActivity.this, toastMsg, Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onListItemCollapsed(int position) {
                Category collapsedCategory = mCategories.get(position);

                collapsedCategory.setExapnded(false);

                String toastMsg = getResources().getString(R.string.collapsed, collapsedCategory.getName());
                //Toast.makeText(GroupsActivity.this, toastMsg, Toast.LENGTH_SHORT).show();
            }
        });

        mRecyclerView.setAdapter(mAdapter);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(this));

    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        //save the expanded and collapsed state of items in our Recycler View during our device configuration changes
        mAdapter.onSaveInstanceState(outState);
    }

    @Override
    protected void onRestoreInstanceState(Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);
        //restore the expanded and collapsed state of items in our Recycler View during our device configuration changes
        mAdapter.onRestoreInstanceState(savedInstanceState);
    }

    /*
    Getting dummy data fro categories and subcategories
     */
    private List<Category> getCategories() {
        List<Category> categories;

        SubCategory project_one = new SubCategory("1", getResources().getString(R.string.project_computer_science_placeholder_atulkaushik), getResources().getString(R.string.project_desc_computer_science_placeholder_atulkaushik), getResources().getString(R.string.project_abstract_computer_science_placeholder_atulkaushik));

        SubCategory project_two = new SubCategory("2", "Project Two", "Project description", "Project detailed contet or project abstract 2");
        SubCategory project_three = new SubCategory("3", "Project Three", "Project description", "Project detailed contet or project abstract 3");
        SubCategory project_four = new SubCategory("4", "Project Four", "Project description", "Project detailed contet or project abstract 4");

        SubCategory project_five = new SubCategory("5", getResources().getString(R.string.project_medical_science_brain_mapping_atulkaushik), getResources().getString(R.string.project_desc_medical_science_brain_mapping_atulkaushik), getResources().getString(R.string.project_abstract_medical_science_brain_mapping_atulkaushik));
        SubCategory project_six = new SubCategory("6", "Project Six", "Project description", "Project detailed contet or project abstract 6");
        SubCategory project_seven = new SubCategory("7", "Project Seven", "Project description", "Project detailed contet or project abstract 7");
        SubCategory project_eight = new SubCategory("8", "Project Eight", "Project description", "Project detailed contet or project abstract 8");

        SubCategory project_nine = new SubCategory("9", getResources().getString(R.string.project_astrophysics_solar_study_atulkaushik), getResources().getString(R.string.project_desc_astrophysics_solar_study_atulkaushik), getResources().getString(R.string.project_abstract_astrophysics_solar_study_atulkaushik));
        SubCategory project_ten = new SubCategory("10", "Project Ten", "Project description", "Project detailed contet or project abstract 10");
        SubCategory project_eleven = new SubCategory("11", "Project Eleven", "Project description", "Project detailed contet or project abstract 11");
        SubCategory project_tweleve = new SubCategory("12", "Project Twelve", "Project description", "Project detailed contet or project abstract 12");

        SubCategory project_thirteen = new SubCategory("13", getResources().getString(R.string.project_graphics_threeD_atulkaushik), getResources().getString(R.string.project_desc_graphics_threeD_atulkaushik), getResources().getString(R.string.project_abstract_graphics_threeD_atulkaushik));
        SubCategory project_fourteen = new SubCategory("14", "Project Eleven", "Project description", "Project detailed contet or project abstract 11");
        SubCategory project_fifteen = new SubCategory("15", "Project Twelve", "Project description", "Project detailed contet or project abstract 12");

        //Populating categories with their subcategories
        Category group_category_one = new Category(getResources().getString(R.string.group_computer_science), Arrays.asList(project_one, project_two, project_three, project_four));
        Category group_category_two = new Category(getResources().getString(R.string.group_medical_science), Arrays.asList(project_five, project_six, project_seven, project_eight));
        Category group_category_three = new Category(getResources().getString(R.string.group_astrophysics), Arrays.asList(project_nine, project_ten, project_eleven, project_tweleve));
        Category group_category_four = new Category(getResources().getString(R.string.group_others), Arrays.asList(project_thirteen, project_fourteen, project_fifteen));

        categories = Arrays.asList(group_category_one, group_category_two, group_category_three, group_category_four);

        return categories;
    }


    public Category getCurrentCategory() {
        return mCurrentCategory;
    }

    public void setCurrentSubCategory(String currentSubcategory) {
        this.mCurrentSubcategory = currentSubcategory;
    }

    public View getfragmentContainer(){
        return mfragmentContainer;
    }

    public void getProject(View view) {
        if (mCurrentSubcategory == null){
            Toast.makeText(GroupsActivity.this, "Error, no such project", Toast.LENGTH_SHORT).show();
            return;
        }

        if (mCurrentSubcategory.equalsIgnoreCase(getResources().getString(R.string.project_computer_science_placeholder_atulkaushik))){
            //Toast.makeText(GroupsActivity.this, "Dashboard Activity", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(getBaseContext(), SampleDashboardActivity.class);
            intent.putExtra("prefs", getResources().getString(R.string.project_computer_science_placeholder_atulkaushik));

                startActivity(intent);
        }else if(mCurrentSubcategory.equalsIgnoreCase(getResources().getString(R.string.project_medical_science_brain_mapping_atulkaushik))){
            Intent intent = new Intent(getBaseContext(), BrainDashboardActivity.class);
            intent.putExtra("prefs", getResources().getString(R.string.project_medical_science_brain_mapping_atulkaushik));

            startActivity(intent);
        }else if(mCurrentSubcategory.equalsIgnoreCase(getResources().getString(R.string.project_astrophysics_solar_study_atulkaushik))){
            Intent intent = new Intent(getBaseContext(), SolarDashboardActivity.class);
            intent.putExtra("prefs", getResources().getString(R.string.project_astrophysics_solar_study_atulkaushik));

            startActivity(intent);
        }
    }

    /**
     * Close all expanded categories
     */
    public void collapseAllCategories(){
        if (mAdapter != null){
            mAdapter.collapseAllParents();
        }
    }
}