package edu.gsu.mllab.androidclient.data.remote;

import android.util.Log;
import com.squareup.otto.Produce;

import java.io.IOException;
import java.util.List;

import edu.gsu.mllab.androidclient.Utils.Constants;
import edu.gsu.mllab.androidclient.data.model.GitHubRepo;
import edu.gsu.mllab.androidclient.data.model.User;
import edu.gsu.mllab.androidclient.events.ErrorEvent;
import edu.gsu.mllab.androidclient.events.ServerEvent;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.ResponseBody;
import okhttp3.logging.HttpLoggingInterceptor;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

import static edu.gsu.mllab.androidclient.Utils.Constants.JSON;

/**
 * Created by mllab on 1/16/18.
 */

/**
 * Communication Framework for various services/APIs
 */
public class Communicator {
    private static final String TAG = Communicator.class.getSimpleName();

    @Produce
    public ServerEvent produceServerEvent(Object serverResponse) {
        return new ServerEvent(serverResponse);
    }

    @Produce
    public ErrorEvent produceErrorEvent(int errorCode, String errorMsg) {
        return new ErrorEvent(errorCode, errorMsg);
    }

    /********************** TEST API CALLS ************************/

    public void getRepos(String user) {//(String username, String password){

        // Create a very simple REST adapter which points the GitHub API endpoint.
        GitHubAPI client = getRetrofitInstance(Constants.TEST_API_BASE_URL).create(GitHubAPI.class);

        // Fetch a list of the Github repositories.
        Call<List<GitHubRepo>> call =
                client.reposForUser(user);

        // Execute the call asynchronously. Get a positive or negative callback.
        call.enqueue(new Callback<List<GitHubRepo>>() {
            @Override
            public void onResponse(Call<List<GitHubRepo>> call, Response<List<GitHubRepo>> response) {
                // The network call was a success and we got a response
                // TODO: use the repository list and display it
                List<GitHubRepo> repos = response.body();
                Log.i(TAG, "Response size =" + repos.size());
                Log.i(TAG,"Success");
                // response.isSuccessful() is true if the response code is 2xx
                //BusProvider.getInstance().post(new ServerEvent(response.body()));
                BusProvider.getInstance().post(new ServerEvent(repos));
            }

            @Override
            public void onFailure(Call<List<GitHubRepo>> call, Throwable t) {
                // the network call was a failure
                // handle execution failures like no internet connectivity
                BusProvider.getInstance().post(new ErrorEvent(-2,t.getMessage()));
                // TODO: handle error
                Log.e(TAG, "ERROR - Response");
                Log.e(TAG, "Error Msg " + t.getLocalizedMessage());
            }
        });
    }

    public String createGroup(String username, String email, String group1, String group2) {
            return "{"
                    + "'username':"
                    +"'"
                    +username
                    +"',"
                    + "'email':"
                    +email
                    +","
                    + "'groups':["
                    + "{'name':'" + group1 + "','detail_1':[10,8,6,7,8],'detail_2':-13388315,'detail_3':39},"
                    + "{'name':'" + group2 + "','detail_1':[6,10,5,10,10],'detail_2':-48060,'detail_3':41}"
                    + "]}";

        /**"{'organization':'Emory University Department of Medicine',"
                + "'name':'Division of Cardiology',"
                + "'hog':4,"
                + "'lastSaved':1367702411696,"
                + "'dateStarted':1367702378785,"
                + "'members':["
                + "{'name':'" + player1 + "','history':[10,8,6,7,8],'color':-13388315,'total':39},"
                + "{'name':'" + player2 + "','history':[6,10,5,10,10],'color':-48060,'total':41}"
                + "]"
                + "'projects':["
                + "{'id':'" + player1 + "','history':[10,8,6,7,8],'color':-13388315,'total':39},"
                + "{'id':'" + player2 + "','history':[6,10,5,10,10],'color':-48060,'total':41}"
                + "]"
                + "'hog':["
                + "{'name':'" + player1 + "','history':[10,8,6,7,8],'color':-13388315,'total':39},"
                + "{'name':'" + player2 + "','history':[6,10,5,10,10],'color':-48060,'total':41}"
                + "]}";*/
    }

    /********************** SIGNUP API CALLs ************************/


 /********************** USER API CALLS ************************/
 public void signup(final User user){

     // Create a very simple REST adapter which points the Users API endpoint.
     UserAPI client = getRetrofitInstance(Constants.LOCAL_HOST).create(UserAPI.class);

     // Fetch a list of the users for given project id.
     Call<User> call =
             client.createUser(user);

     // Execute the call asynchronously. Get a positive or negative callback.
     call.enqueue(new Callback<User>() {
         @Override
         public void onResponse(Call<User> call, Response<User> response) {
             // The network call was a success and we got a response
             // TODO: use the repository list and display it
             Object object = response.body();

             Log.i(TAG,"registration SUCCESS for user = "+user.getName());
             Log.i(TAG,"SUCCESS object = "+object);
             BusProvider.getInstance().post(new ServerEvent("registration done SUCCESSfully"));
             //Log.i(TAG, "Users size =" + users.size());

         }

         @Override
         public void onFailure(Call<User> call, Throwable t) {
             // the network call was a failure
             // handle execution failures like no internet connectivity
             BusProvider.getInstance().post(new ErrorEvent(-2,t.getMessage()));
             // TODO: handle error
             Log.e(TAG, "ERROR - Response");
             Log.e(TAG, "Error Msg " + t.getLocalizedMessage());
         }
     });
 }


    public void login(final String username, final String password){

     // Create a very simple REST adapter which points the Users API endpoint.
     UserAPI client = getRetrofitInstance(Constants.LOCAL_HOST).create(UserAPI.class);

     // Fetch a list of the users for given project id.
     Call<List<User>> call =
             client.getUsers();

     // Execute the call asynchronously. Get a positive or negative callback.
     call.enqueue(new Callback<List<User>>() {
         @Override
         public void onResponse(Call<List<User>> call, Response<List<User>> response) {
             // The network call was a success and we got a response
             // TODO: use the repository list and display it
             List<User> users = response.body();
             Log.i(TAG, "No of users =" + users.size());
             Log.i(TAG, "given email =" + username);
             Log.i(TAG, "given password =" + password);
             String login_failure_msg="login api failed";
             boolean api_failed = true;
             for (User usr : users){
                 Log.i(TAG, "email =" + usr.getEmail());
                 Log.i(TAG, "password =" + usr.getPassword());
                 if(usr.getEmail().trim().equals(username.trim()) ){
                     if(usr.getPassword().trim().equals(password.trim())){
                         Log.i(TAG,"Login SUCCESS for user = "+username);
                         // response.isSuccessful() is true if the response code is 2xx
                         BusProvider.getInstance().post(new ServerEvent(true));
                         api_failed = false;
                         break;
                     } else {
                         Log.i(TAG,"Login FAILED for user = "+username +" incorrect password!");
                         login_failure_msg = "incorrect password!";
                         break;
                     }
                 }else {
                     Log.i(TAG,"Login FAILED for user = "+username+" email does not exist!");
                     login_failure_msg = "email does not exist!";
                 }
             }
             if (api_failed) {
                 BusProvider.getInstance().post(new ServerEvent(login_failure_msg));
             }
             //Log.i(TAG, "Users size =" + users.size());

         }

         @Override
         public void onFailure(Call<List<User>> call, Throwable t) {
             // the network call was a failure
             // handle execution failures like no internet connectivity
             BusProvider.getInstance().post(new ErrorEvent(-2,t.getMessage()));
             // TODO: handle error
             Log.e(TAG, "ERROR - Response");
             Log.e(TAG, "Error Msg " + t.getLocalizedMessage());
         }
     });
 }
    /**
     * Get users for a given group
     * @param group
     */
    public void getUsers(String group) {//(String username, String password){

        // Create a very simple REST adapter which points the Users API endpoint.
        UserAPI client = getRetrofitInstance(Constants.LOCAL_HOST).create(UserAPI.class);

        // Fetch a list of the users for given project id.
        Call<List<User>> call =
                client.getUsers();

        // Execute the call asynchronously. Get a positive or negative callback.
        call.enqueue(new Callback<List<User>>() {
            @Override
            public void onResponse(Call<List<User>> call, Response<List<User>> response) {
                // The network call was a success and we got a response
                // TODO: use the repository list and display it
                List<User> users = response.body();
                //Log.i(TAG, "No of users =" + users.size());
                //Log.i(TAG,"Success object= "+users);
                // response.isSuccessful() is true if the response code is 2xx
                BusProvider.getInstance().post(new ServerEvent(users));
            }

            @Override
            public void onFailure(Call<List<User>> call, Throwable t) {
                // the network call was a failure
                // handle execution failures like no internet connectivity
                BusProvider.getInstance().post(new ErrorEvent(-2,t.getMessage()));
                // TODO: handle error
                Log.e(TAG, "ERROR - Response");
                Log.e(TAG, "Error Msg " + t.getLocalizedMessage());
            }
        });
    }

    /**
     * Get user by id
     * @param id
     */
    public void getUserById(String id) {

        // Create a very simple REST adapter which points the Users API endpoint.
        UserAPI client = getRetrofitInstance(Constants.LOCAL_HOST).create(UserAPI.class);

        // Fetch a list of the users for given project id.
        Call<User> call =
                client.getUserById(id);

        // Execute the call asynchronously. Get a positive or negative callback.
        call.enqueue(new Callback<User>() {
            @Override
            public void onResponse(Call<User> call, Response<User> response) {
                // The network call was a success and we got a response
                // TODO: use the repository list and display it
                User user = response.body();
                Log.i(TAG, "User Name =" + user.getName());
                Log.i(TAG,"Success");
                // response.isSuccessful() is true if the response code is 2xx
                BusProvider.getInstance().post(new ServerEvent(user));
            }

            @Override
            public void onFailure(Call<User> call, Throwable t) {
                // the network call was a failure
                // handle execution failures like no internet connectivity
                BusProvider.getInstance().post(new ErrorEvent(-2,t.getMessage()));
                // TODO: handle error
                Log.e(TAG, "ERROR - Response");
                Log.e(TAG, "Error Msg " + t.getLocalizedMessage());
            }
        });
    }

    public void addUser1(User user) {
       /* OkHttpClient.Builder httpClient = new OkHttpClient.Builder();

        Retrofit.Builder builder =
                new Retrofit.Builder()
                        .baseUrl(host)
                        .addConverterFactory(
                                GsonConverterFactory.create());

        Retrofit retrofit = builder
                .client(httpClient.build())
                .build();

        OkHttpClient client = new OkHttpClient();
        RequestBody body = RequestBody.create(JSON, json);
        Request request = new Request.Builder()
                .url(url)
                .post(body)
                .build();
        try (okhttp3.Response response = client.newCall(request).execute()) {
            return response.body().string();
        }


        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("http://httpbin.org/")
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        BookResourceRetrofit2 bookResource = retrofit.create(BookResourceRetrofit2.class);
        Book book = new Book(1l, "Java How To Program", "Paul Deitel");

        //Call<Book> call = bookResource.addUser(book);
        //Response<ResponseBody> response = call.execute();

        //assertTrue(response.isSuccessful());*/

        // Create a very simple REST adapter which points the Users API endpoint.
        UserAPI client = getRetrofitInstance(Constants.LOCAL_HOST).create(UserAPI.class);

        // Fetch a list of the users for given project id.
        Call<User> call =
                client.addUser(user);

        // Execute the call asynchronously. Get a positive or negative callback.
        call.enqueue(new Callback<User>() {
            @Override
            public void onResponse(Call<User> call, Response<User> response) {
                // The network call was a success and we got a response
                // TODO: use the repository list and display it
                Log.i(TAG, "response.body() =" + response.body());
                Log.i(TAG,"Success");
                // response.isSuccessful() is true if the response code is 2xx
                BusProvider.getInstance().post(new ServerEvent(true));
            }

            @Override
            public void onFailure(Call<User> call, Throwable t) {
                // the network call was a failure
                // handle execution failures like no internet connectivity
                BusProvider.getInstance().post(new ErrorEvent(-2,t.getMessage()));
                // TODO: handle error
                Log.e(TAG, "ERROR - Response");
                Log.e(TAG, "Error Msg " + t.getLocalizedMessage());
            }
        });
    }

    public void addUser(User user){
        OkHttpClient.Builder httpClient = new OkHttpClient.Builder();
       // HttpLoggingInterceptor loggingInterceptor = new HttpLoggingInterceptor();
       // loggingInterceptor.setLevel(HttpLoggingInterceptor.Level.BODY);
       // httpClient.addInterceptor(loggingInterceptor);

        Retrofit.Builder builder =
                new Retrofit.Builder()
                        .baseUrl(Constants.LOCAL_HOST)
                        .addConverterFactory(
                                GsonConverterFactory.create());

        Retrofit retrofit = builder
                .client(httpClient.build())
                .build();

        UserAPI apiService = retrofit.create(UserAPI.class);
        Call<User> call = apiService.addUser(user);
        call.enqueue(new Callback<User>() {
            @Override
            public void onResponse(Call<User> call, Response<User> response) {

                int statusCode = response.code();

                Log.i(TAG, "Status Code: " + statusCode);

            }

            @Override
            public void onFailure(Call<User> call, Throwable t) {
                Log.i(TAG, "Error: " + t.toString());
            }

        });
    }

    public String postData(String url, String json) throws IOException {
        OkHttpClient client = new OkHttpClient();
        RequestBody body = RequestBody.create(JSON, json);
        Request request = new Request.Builder()
                .url(url)
                .post(body)
                .build();
        try (okhttp3.Response response = client.newCall(request).execute()) {
            return response.body().string();
        }
    }

    private Retrofit getRetrofitInstance(String host){
        OkHttpClient.Builder httpClient = new OkHttpClient.Builder();

        Retrofit.Builder builder =
                new Retrofit.Builder()
                        .baseUrl(host)
                        .addConverterFactory(
                                GsonConverterFactory.create());

        Retrofit retrofit = builder
                .client(httpClient.build())
                .build();
        return retrofit;
    }
}
