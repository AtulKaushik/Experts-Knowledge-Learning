package edu.gsu.mllab.androidclient.bitmap;

import android.graphics.Bitmap;
import android.os.AsyncTask;
import android.os.Environment;

import java.io.File;
import java.io.IOException;

import edu.gsu.mllab.androidclient.Utils.Constants;

public class BitmapTask extends AsyncTask<BitmapInput, Void, BitmapResult> {

    private final BitmapCallback callback;
    private boolean isOOMThrown = false;

    public BitmapTask(BitmapCallback callback) {
        this.callback = callback;
    }

    @Override
    protected BitmapResult doInBackground(BitmapInput... params) {
        Bitmap bitmap = null;
        try {
            bitmap = params[0].getOriginalBitmap();
            if (bitmap != null) {
                    BitmapUtils.writeBitmapToFile(bitmap, new File(Environment.getExternalStorageDirectory() + Constants.ROOT_FILE_PATH+ BitmapUtils.getBitmapName()), Constants.COMPRESSION_RATIO);
            }

        } catch (OutOfMemoryError e) {
            isOOMThrown = true;
            return null;
        } catch (IllegalArgumentException e) {
            return BitmapResult.error();
        } catch (IOException e) {
            e.printStackTrace();
            return BitmapResult.error();
        }
        return BitmapResult.success(bitmap);
    }

    @Override
    protected void onPreExecute() {
        if (callback != null){
            callback.onStarted();
        }

    }

    @Override
    protected void onPostExecute(BitmapResult result) {
        if (result == null || isOOMThrown) {
            if (callback != null) {
                callback.onOutOfMemoryError();
            }
            return;
        }

        if (result.getState() == BitmapState.ERROR) {
            if (callback != null) {
                callback.onError();
            }
        }

        if (result.getBitmap() != null) {
            if (callback != null) {
                callback.onSaved(result.getBitmap());
            }
        }
    }

}
