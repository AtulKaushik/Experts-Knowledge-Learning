/*
 * Copyright 2014 Gabriele Mariotti
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package edu.gsu.mllab.androidclient.activity;

import android.app.Fragment;
import android.content.Context;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import butterknife.ButterKnife;
//import butterknife.InjectView;
import butterknife.BindView;

import com.bumptech.glide.request.animation.GlideAnimation;
import com.bumptech.glide.request.target.SimpleTarget;
import com.davemorrissey.labs.subscaleview.ImageSource;
import com.davemorrissey.labs.subscaleview.SubsamplingScaleImageView;

import java.util.ArrayList;
import java.util.List;

import edu.gsu.mllab.androidclient.R;

/**
 * Created by mllab on 1/26/18.
 */

public class CustomShapeFragment extends Fragment implements View.OnClickListener{

    public static final String TAG = CustomShapeFragment.class.getSimpleName();

    private ArrayList<String> _images;
    private GalleryPagerAdapter _adapter;


    ViewPager _pager;
    LinearLayout _thumbnails;
    ImageButton _closeButton;
    ImageButton leftNav;
    ImageButton rightNav;


    //TODO: above this
    private int checkedId;

    public CustomShapeFragment(){
        super();
    }

    protected CustomDrawingView mCustomDrawingView;
    //public SubsamplingScaleImageView customImage;
    //public ImageView customImage;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.customshape_fragment, container, false);
        mCustomDrawingView = (CustomDrawingView) rootView.findViewById(R.id.drawingview);
        //customImage = (ImageView) rootView.findViewById(R.id.imageData);

        _pager = rootView.findViewById(R.id.pager);
        _closeButton  = rootView.findViewById(R.id.btn_close);
        _thumbnails  = rootView.findViewById(R.id.thumbnails);

        leftNav = rootView.findViewById(R.id.left_nav);
        rightNav = rootView.findViewById(R.id.right_nav);

        _closeButton.setOnClickListener(this);
        leftNav.setOnClickListener(this);
        rightNav.setOnClickListener(this);
        //TODO : Below this
        //get imageview of adapter (detail/large)
        //customImage = rootView.findViewById(R.id.imageData)
        //ButterKnife.inject(getActivity());
        ButterKnife.bind(getActivity());

        //_images = (ArrayList<String>) getIntent().getSerializableExtra(EXTRA_NAME);
        //Assert.assertNotNull(_images);
        _images = getImages();

        _adapter = new GalleryPagerAdapter(getContext());
        _pager.setAdapter(_adapter);
        _pager.setOffscreenPageLimit(6); // how many images to load into memory
/*
        _closeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d(TAG, "Close clicked");
                getActivity().finish();
            }
        });

        // Images left navigation
        leftNav.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getActivity(), "Left Nav Clicked", Toast.LENGTH_LONG).show();
                int tab = _pager.getCurrentItem();
                if (tab > 0) {
                    tab--;
                    _pager.setCurrentItem(tab);
                } else if (tab == 0) {
                    _pager.setCurrentItem(tab);
                }
            }
        });

        // Images right navigatin
        rightNav.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getActivity(), "Right Nav Clicked", Toast.LENGTH_LONG).show();
                int tab = _pager.getCurrentItem();
                tab++;
                _pager.setCurrentItem(tab);
            }
        });
*/
        //Bind the step indicator to the adapter
        //viewPagerArrowIndicator = (ViewPagerArrowIndicator) findViewById(R.id.viewPagerArrowIndicator);
        //viewPager.setAdapter(new MyPagerAdapter(getSupportFragmentManager()));

        //viewPagerArrowIndicator.bind(viewPager);

        //TODO : above this

        return rootView;
    }

    /**
     * This method is invoked from menu options. Just uncomment the theme in manifest and it will become visible
     * @param item
     * @return
     */
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        switch (item.getItemId()){
            case R.id.action_line:
                mCustomDrawingView.mCurrentShape = CustomDrawingView.LINE;
                mCustomDrawingView.reset();
                break;
            case R.id.action_smoothline:
                mCustomDrawingView.mCurrentShape = CustomDrawingView.SMOOTHLINE;
                mCustomDrawingView.reset();
                break;
            case R.id.action_rectangle:
                mCustomDrawingView.mCurrentShape = CustomDrawingView.RECTANGLE;
                mCustomDrawingView.reset();
                break;
            case R.id.action_square:
                mCustomDrawingView.mCurrentShape = CustomDrawingView.SQUARE;
                mCustomDrawingView.reset();
                break;
            case R.id.action_circle:
                mCustomDrawingView.mCurrentShape = CustomDrawingView.CIRCLE;
                mCustomDrawingView.reset();
                break;
            case R.id.action_triangle:
                mCustomDrawingView.mCurrentShape = CustomDrawingView.TRIANGLE;
                mCustomDrawingView.reset();
                break;

        }

        return super.onOptionsItemSelected(item);
    }

    /**
     * This method is being invoked from radio group buttons
     * @param checkedId
     */
    public void initializeCustomDrawing(int checkedId){
        switch (checkedId){
            case R.id.radioLine:
                mCustomDrawingView.mCurrentShape = CustomDrawingView.LINE;
                mCustomDrawingView.reset();
                break;
            case R.id.radioSmoothline:
                mCustomDrawingView.mCurrentShape = CustomDrawingView.SMOOTHLINE;
                mCustomDrawingView.reset();
                break;
            case R.id.radioRectangle:
                mCustomDrawingView.mCurrentShape = CustomDrawingView.RECTANGLE;
                mCustomDrawingView.reset();
                break;
            case R.id.radioSquare:
                mCustomDrawingView.mCurrentShape = CustomDrawingView.SQUARE;
                mCustomDrawingView.reset();
                break;
            case R.id.radioCircle:
                mCustomDrawingView.mCurrentShape = CustomDrawingView.CIRCLE;
                mCustomDrawingView.reset();
                break;
            case R.id.radioTriangle:
                mCustomDrawingView.mCurrentShape = CustomDrawingView.TRIANGLE;
                mCustomDrawingView.reset();
                break;

        }

    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btn_close:
                Toast.makeText(getActivity(), "Close Button Clicked", Toast.LENGTH_LONG).show();
                break;
            case R.id.left_nav:
                Toast.makeText(getActivity(), "Left Nav Clicked", Toast.LENGTH_LONG).show();
                break;
            case R.id.right_nav:
                Toast.makeText(getActivity(), "Right Nav Clicked", Toast.LENGTH_LONG).show();
                break;

            default:
                break;
        }
    }

    //TODO : Below this
    class GalleryPagerAdapter extends PagerAdapter {

        Context _context;
        LayoutInflater _inflater;

        public GalleryPagerAdapter(Context context) {
            _context = context;
            _inflater = (LayoutInflater) _context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        }

        @Override
        public int getCount() {
            return _images.size();
        }

        @Override
        public boolean isViewFromObject(View view, Object object) {
            return view == ((LinearLayout) object);
        }

        @Override
        public Object instantiateItem(ViewGroup container, final int position) {
            View itemView = _inflater.inflate(R.layout.pager_gallery_item, container, false);
            container.addView(itemView);

            // Get the border size to show around each image
            int borderSize = _thumbnails.getPaddingTop();

            // Get the size of the actual thumbnail image
            int thumbnailSize = ((FrameLayout.LayoutParams)
                    _pager.getLayoutParams()).bottomMargin - (borderSize*2);

            // Set the thumbnail layout parameters. Adjust as required
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(thumbnailSize, thumbnailSize);
            params.setMargins(0, 0, borderSize, 0);

            // You could also set like so to remove borders
            //ViewGroup.LayoutParams params = new ViewGroup.LayoutParams(
            //        ViewGroup.LayoutParams.WRAP_CONTENT,
            //        ViewGroup.LayoutParams.WRAP_CONTENT);

            final ImageView thumbView = new ImageView(_context);
            thumbView.setScaleType(ImageView.ScaleType.CENTER_CROP);
            thumbView.setLayoutParams(params);
            thumbView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Log.d(TAG, "Thumbnail clicked");
                    //Toast.makeText(_context, "Page Clicked : "+position, Toast.LENGTH_LONG).show();
                    // Set the pager position when thumbnail clicked
                    _pager.setCurrentItem(position);
                }
            });

            _thumbnails.addView(thumbView);

            /**
             TextView page = new TextView(_context);
             page.setLayoutParams(params);
             page.setPadding(1, 1, 1, 1);
             page.setTypeface(Typeface.DEFAULT_BOLD);

             page.setGravity(Gravity.CENTER);
             page.setText(Integer.toString(position));
             _pageNumber.addView(page);
             */

            final SubsamplingScaleImageView imageView =
                    (SubsamplingScaleImageView) itemView.findViewById(R.id.image);

            // Asynchronously load the image and set the thumbnail and pager view
            Glide.with(_context)
                    .load(_images.get(position))
                    .asBitmap()
                    .into(new SimpleTarget<Bitmap>() {
                        @Override
                        public void onResourceReady(Bitmap bitmap, GlideAnimation anim) {
                            imageView.setImage(ImageSource.bitmap(bitmap));
                            thumbView.setImageBitmap(bitmap);
                        }
                    });

            return itemView;
        }

        @Override
        public void destroyItem(ViewGroup container, int position, Object object) {
            container.removeView((LinearLayout) object);
        }
    }



    private ArrayList<String> getImages(){
        ArrayList<String> images = new ArrayList<String>();
        images.add("http://dmlab.cs.gsu.edu/dmlabapi/images/SDO/AIA/2k/?wave=171&starttime=2012-02-13T20:10:00");
        images.add("http://dmlab.cs.gsu.edu/dmlabapi/images/SDO/AIA/2k/?wave=131&starttime=2012-02-13T20:10:00");
        images.add("http://dmlab.cs.gsu.edu/dmlabapi/images/SDO/AIA/2k/?wave=193&starttime=2012-02-13T20:10:00");
        images.add("http://dmlab.cs.gsu.edu/dmlabapi/images/SDO/AIA/2k/?wave=211&starttime=2012-02-13T20:10:00");
        images.add("http://dmlab.cs.gsu.edu/dmlabapi/images/SDO/AIA/2k/?wave=304&starttime=2012-02-13T20:10:00");
        images.add("http://dmlab.cs.gsu.edu/dmlabapi/images/SDO/AIA/2k/?wave=335&starttime=2012-02-13T20:10:00");
        return images;
    }
}
