package edu.gsu.mllab.androidclient.bitmap;


import android.graphics.Bitmap;

/**
 * Any bitmap information can stored in this object
 */
public class BitmapInput {

    private String bitmapInfo;
    private Bitmap originalBitmap;

    private static final String TAG = BitmapInput.class.getSimpleName();

    public BitmapInput(String bitmapInput, Bitmap originalBitmap) {
        this.bitmapInfo = bitmapInput;
        this.originalBitmap = originalBitmap;
    }

    public Bitmap getOriginalBitmap() {
        return originalBitmap;
    }

    public void setOriginalBitmap(Bitmap originalBitmap) {
        this.originalBitmap = originalBitmap;
    }

    public String getBitmapInfo() {
        return bitmapInfo;
    }

    public void setBitmapInfo(String bitmapInfo) {
        this.bitmapInfo = bitmapInfo;
    }


}
