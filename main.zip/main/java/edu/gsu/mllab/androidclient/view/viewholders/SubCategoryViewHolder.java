package edu.gsu.mllab.androidclient.view.viewholders;

import android.view.View;
import android.widget.TextView;

import edu.gsu.mllab.androidclient.R;
import edu.gsu.mllab.androidclient.data.model.SubCategory;
import edu.gsu.mllab.androidclient.view.recyclerView.base.root.ChildViewHolder;

public class SubCategoryViewHolder extends ChildViewHolder {

    private TextView mSubcategoryTextView;

    public SubCategoryViewHolder(View itemView) {
        super(itemView);
        mSubcategoryTextView = (TextView) itemView.findViewById(R.id.tv_subcategory);
    }

    /*
    Setting the subcategory label
     */
    public void bind(SubCategory subCategory) {
        mSubcategoryTextView.setText(subCategory.getName());
    }
}
