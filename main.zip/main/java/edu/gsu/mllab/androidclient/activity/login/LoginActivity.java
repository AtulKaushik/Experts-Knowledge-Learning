package edu.gsu.mllab.androidclient.activity.login;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.squareup.otto.Subscribe;

import butterknife.BindView;
import butterknife.ButterKnife;
import edu.gsu.mllab.androidclient.R;
import edu.gsu.mllab.androidclient.placeholder.PlaceHolderActivity;
import edu.gsu.mllab.androidclient.activity.signup.SignupActivity;
import edu.gsu.mllab.androidclient.data.model.User;
import edu.gsu.mllab.androidclient.data.remote.BusProvider;
import edu.gsu.mllab.androidclient.data.remote.Communicator;
import edu.gsu.mllab.androidclient.events.ErrorEvent;
import edu.gsu.mllab.androidclient.events.ServerEvent;
import edu.gsu.mllab.androidclient.activity.groups.GroupsActivity;

public class LoginActivity extends AppCompatActivity {
    private Communicator communicator;
    private static final String TAG = LoginActivity.class.getSimpleName();
    //private static final String TAG = "LoginActivity";
    private static final int REQUEST_SIGNUP = 0;

    @BindView(R.id.input_email)
    EditText _emailText;
    @BindView(R.id.input_password)
    EditText _passwordText;
    @BindView(R.id.btn_login)
    Button _loginButton;
    @BindView(R.id.link_signup)
    TextView _signupLink;
    
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        ButterKnife.bind(this);

        communicator = new Communicator();

        _loginButton.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                //TODO: uncomment this for login api service invokation
                //login();

                // TODO: this is temp code, remove it
                if(testDummyCredentials(validate())){
                    Intent intent = new Intent(getBaseContext(), GroupsActivity.class);
                    startActivity(intent);
                }
            }
        });

        _signupLink.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // Start the Signup activity
                Intent intent = new Intent(getApplicationContext(), SignupActivity.class);
                startActivityForResult(intent, REQUEST_SIGNUP);
                //finish();
                overridePendingTransition(R.anim.push_left_in, R.anim.push_left_out);
            }
        });
    }

    /***************** REST API Functionalities *****************/

    private void usePost(String username, String password){
        //communicator.loginPost(username, password);
    }

    private void getRepos(String user){
        communicator.getRepos(user);
    }

    private void getUsers(String group){
        communicator.getUsers(group);
    }

    private void login(String usr, String pwd){
        communicator.login(usr, pwd);
    }

    private void addUser(User user){
        communicator.addUser(user);
    }

    private void getUserById(String id){
        communicator.getUserById(id);
    }

    /**
     * Subscribing listeners to server events
     * @param serverEvent
     */
    @Subscribe
    public void onServerEvent(ServerEvent serverEvent) {
        Object response = serverEvent.getServerResponse();
        if (response != null) {
            if (response instanceof Boolean) {
                Toast.makeText(this,"Login Sucsessfull",Toast.LENGTH_SHORT).show();
                // Start the Signup activity
                Intent intent = new Intent(this, PlaceHolderActivity.class);
                startActivity(intent);
            } else {
                Toast.makeText(this,(String)response,Toast.LENGTH_SHORT).show();
            }

        }

        /*if (response != null) {
            Log.v(TAG, "Received the ServerEvent SUCCESSFULLY!!");
            if (response instanceof List && !((List) response).isEmpty()) {
                if (((List) response).get(0) instanceof GitHubRepo) {
                    List<GitHubRepo> repos = (List<GitHubRepo>) serverEvent.getServerResponse();
                    Log.d(TAG, "Github Repository size =" + repos.size());
                } else if (((List) response).get(0) instanceof User) {
                    List<User> users = (List<User>) serverEvent.getServerResponse();
                    Log.d(TAG, "No. of users =" + users.size());
                    for (User usr : users){
                        Log.i(TAG, "name =" + usr.getName());
                        Log.i(TAG, "email =" + usr.getEmail());
                        Log.i(TAG, "group =" + usr.getGroup());
                        Log.i(TAG, "id =" + usr.getId());
                    }

                }

                //Toast.makeText(this, ""+serverEvent.getServerResponse().toString(), Toast.LENGTH_SHORT).show();
                //if(serverEvent.getServerResponse().getUsername() != null){
                //information.setText("Username: "+serverEvent.getServerResponse().getUsername() + " || Password: "+serverEvent.getServerResponse().getPassword());
            } else if(response instanceof User){
                User user = (User) serverEvent.getServerResponse();
            }
        }*/
            //extraInformation.setText("" + serverEvent.getServerResponse().getMessage());
        }

    /**
     * Subscribing listeners to error events
     * @param errorEvent
     */
    @Subscribe
    public void onErrorEvent(ErrorEvent errorEvent){
        Log.e(TAG,"Received the ServerError!!");
        Toast.makeText(this,""+errorEvent.getErrorMsg(),Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onResume(){
        super.onResume();
        //Registering this activity as a listener
        BusProvider.getInstance().register(this);
    }

    @Override
    public void onPause(){
        super.onPause();
        //Un-Registering this activity as a listener
        BusProvider.getInstance().unregister(this);
    }

    /***************** Login Functionalities *****************/

    public void login() {
        Log.d(TAG, "Login");

        if (!validate()) {
            onLoginFailed();
            return;
        }

        _loginButton.setEnabled(false);

        final ProgressDialog progressDialog = new ProgressDialog(LoginActivity.this,
                R.style.AppTheme_Dark_Dialog);
        progressDialog.setIndeterminate(true);
        progressDialog.setMessage("Authenticating...");
        progressDialog.show();

        String email = _emailText.getText().toString();
        String password = _passwordText.getText().toString();

        // TODO: Implement your own authentication logic here.

        login(email, password);
        //addUser(new User("John","john.snow@got.com", null));//new String[]{"night's watch", "dragonstone", "winterfell"}));
        // TODO ATUL: For test only
        //getRepos("fs-opensource");

        new android.os.Handler().postDelayed(
                new Runnable() {
                    public void run() {
                        // On complete call either onLoginSuccess or onLoginFailed
                        onLoginSuccess();
                        // onLoginFailed();
                        progressDialog.dismiss();
                    }
                }, 3000);
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == REQUEST_SIGNUP) {
            if (resultCode == RESULT_OK) {

                // TODO: Implement successful signup logic here
                // By default we just finish the Activity and log them in automatically
                Toast.makeText(getBaseContext(), "successful signup coming soon", Toast.LENGTH_LONG).show();
                //this.finish();
            }
        }
    }

    @Override
    public void onBackPressed() {
        // Disable going back to the PlaceHolderActivity
        moveTaskToBack(true);
    }

    public void onLoginSuccess() {
        _loginButton.setEnabled(true);
        //finish();
    }

    public void onLoginFailed() {
        Toast.makeText(getBaseContext(), "Login failed", Toast.LENGTH_LONG).show();

        _loginButton.setEnabled(true);
    }

    public boolean validate() {
        boolean valid = true;

        String email = _emailText.getText().toString();
        String password = _passwordText.getText().toString();

        if (email.isEmpty() || !android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            _emailText.setError("enter a valid email address");
            valid = false;
        } else {
            _emailText.setError(null);
        }

        if (password.isEmpty() || password.length() < 4 || password.length() > 10) {
            _passwordText.setError("between 4 and 10 alphanumeric characters");
            valid = false;
        } else {
            _passwordText.setError(null);
        }

        return valid;
    }

    public boolean testDummyCredentials(boolean validEmail){
        if(!validEmail){
            return false;
        }
        boolean validated = true;

            String email = _emailText.getText().toString();
            String password = _passwordText.getText().toString();

            if (!email.isEmpty() && !email.equalsIgnoreCase("test@gsu.edu")) {
                validated = false;
                Toast.makeText(LoginActivity.this, "try email : test@gsu.edu", Toast.LENGTH_LONG).show();
            }
            if(!password.isEmpty() && !password.equalsIgnoreCase("test123")) {
                validated = false;
                Toast.makeText(LoginActivity.this, "try password : test123", Toast.LENGTH_LONG).show();
            }
            return validated;
        }
}
