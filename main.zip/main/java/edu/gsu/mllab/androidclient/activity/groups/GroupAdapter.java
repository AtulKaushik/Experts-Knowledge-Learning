package edu.gsu.mllab.androidclient.activity.groups;

import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.FragmentManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import java.util.List;

import edu.gsu.mllab.androidclient.R;
import edu.gsu.mllab.androidclient.data.model.Category;
import edu.gsu.mllab.androidclient.data.model.SubCategory;
import edu.gsu.mllab.androidclient.view.recyclerView.base.root.ExpandableRecyclerAdapter;
import edu.gsu.mllab.androidclient.view.recyclerView.base.root.ParentListItem;

public class GroupAdapter extends ExpandableRecyclerAdapter<GroupViewHolder, ProjectViewHolder> {

    private LayoutInflater mInflator;
    private View subcategoryView;
    private View categoryView;
    private SubCategory subcategory;
    private Category category;

    private GroupsActivity activity;

    public GroupAdapter(Context context, List<? extends ParentListItem> parentItemList) {
        super(parentItemList);
        mInflator = LayoutInflater.from(context);
        this.activity = (GroupsActivity) context;
    }

    @Override
    public GroupViewHolder onCreateParentViewHolder(ViewGroup parentViewGroup) {
        //This is category layout in master view of groups activity
        categoryView = mInflator.inflate(R.layout.group_category_view, parentViewGroup, false);
        return new GroupViewHolder(categoryView);
    }

    @Override
    public ProjectViewHolder onCreateChildViewHolder(ViewGroup childViewGroup) {
        //This is the child view in master view of groups activity
        subcategoryView = mInflator.inflate(R.layout.project_subcategory_view, childViewGroup, false);
        return new ProjectViewHolder(subcategoryView);
    }

    @Override
    public void onBindParentViewHolder(GroupViewHolder categoryViewHolder,final int position, ParentListItem parentListItem) {
        category = (Category) parentListItem;
        categoryViewHolder.bind(category);
    }

    @Override
    public void onBindChildViewHolder(final ProjectViewHolder subCategoryViewHolder, final int position, Object childListItem) {
        subcategory = (SubCategory) childListItem;
                subCategoryViewHolder.bind(subcategory);

        subCategoryViewHolder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String label = subCategoryViewHolder.getSubcategoryLabelView().getText().toString();
                SubCategory subCategory = activity.getCurrentCategory().getSubcategoryByName(label);
                //Toast.makeText(activity, "label = "+label, Toast.LENGTH_SHORT).show();

                try {
                    if(subCategory != null){
                        //pass this info to group category
                        activity.setCurrentSubCategory(subCategory.getName());
                        //TODO: At times, We may face problem in getting the true position of nested recycler, Fix it when everything else is fixed.
                        Bundle arguments = new Bundle();
                        arguments.putString(ProjectDetailFragment.ARG_PROJECT_TITLE, (subCategory).getName());
                        arguments.putString(ProjectDetailFragment.ARG_PROJECT_ABSTRACT, (subCategory).getContent());
                        ProjectDetailFragment fragment = new ProjectDetailFragment();
                        fragment.setArguments(arguments);
                        FragmentManager fragmentManager = activity.getSupportFragmentManager();
                        fragmentManager.beginTransaction()
                                .replace(R.id.project_detail_container, fragment)
                                .commit();
                    }else {
                        //TODO: Current Category is set only when category view is clicked, therefore to refresh/reload category, we are collasping all categories
                        activity.collapseAllCategories();
                        Toast.makeText(activity, "Try Again!", Toast.LENGTH_LONG).show();
                    }
                }catch (Exception e){
                    Toast.makeText(activity, "There was some error. Please try again!", Toast.LENGTH_SHORT).show();
                    e.printStackTrace();

                }


                //Toast.makeText(activity, "Recycle Click"+ position, Toast.LENGTH_SHORT).show();

            }
        });
    }

}
