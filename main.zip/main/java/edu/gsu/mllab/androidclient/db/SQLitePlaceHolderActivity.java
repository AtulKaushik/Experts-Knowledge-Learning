package edu.gsu.mllab.androidclient.db;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;

import java.util.List;

import edu.gsu.mllab.androidclient.R;


public class SQLitePlaceHolderActivity extends Activity {
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
        DatabaseHandler db = new DatabaseHandler(this);
        
        /**
         * CRUD Operations
         * */
        // Inserting Contacts
        Log.d("Insert: ", "Inserting ..");

        db.addImageMetaData(new ImageMetaData(1,"image1","classs-1", 910.00f));
        db.addImageMetaData(new ImageMetaData(2,"image2","class-1", 919.99f));
        db.addImageMetaData(new ImageMetaData(3,"image3","class-2", 95.2f));
        db.addImageMetaData(new ImageMetaData(4,"image4","class-2", 953.33f));
 
        // Reading all imageMetaData
        Log.d("Reading: ", "Reading all imageMetaData..");
        List<ImageMetaData> imageMetaData = db.getAllImageMetaData();
 
        for (ImageMetaData cn : imageMetaData) {
            String log = "Id: "+cn.getID()+" ,Name: " + cn.getName() + " ,Phone: " + cn.getClass();
                // Writing Contacts to log
        Log.d("Name: ", log);
        
        }
    }
}