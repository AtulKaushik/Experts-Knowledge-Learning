from django.contrib import admin

# Register your models here.
from .models import Group, Project, Data

admin.site.register(Group)
admin.site.register(Project)
admin.site.register(Data)
