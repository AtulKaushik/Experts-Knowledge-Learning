package edu.gsu.mllab.androidclient.activity.groups.projects.brain;

import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import edu.gsu.mllab.androidclient.R;
import edu.gsu.mllab.androidclient.data.model.SubCategory;
import edu.gsu.mllab.androidclient.view.recyclerView.base.root.ChildViewHolder;

/**
 * Created by mllab on 3/7/18.
 */

public class BrainSubCategoryViewHolder extends ChildViewHolder {

    private TextView mSubcategoryTextView;
    private LinearLayout mProjectListContainer;


    public BrainSubCategoryViewHolder(View itemView) {
        super(itemView);
        mSubcategoryTextView = (TextView) itemView.findViewById(R.id.tv_brain_subcategory_name);
        mProjectListContainer = itemView.findViewById(R.id.brain_subcategory_list_container);
    }

    /*
    Setting the subcategory label
     */
    public void bind(SubCategory subCategory) {
        mSubcategoryTextView.setText(subCategory.getName());

    }

    public View getContainer(){
        return mProjectListContainer;
    }

    public TextView getSubcategoryLabelView(){
        return mSubcategoryTextView;
    }

}

