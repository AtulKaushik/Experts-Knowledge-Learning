package edu.gsu.mllab.androidclient.db;

public class ImageMetaData {
	
	//private variables
	private int _id;
    private String _name;
    private String _coordinate_class;
    private float _coordiante;
    private byte [] _imageInByte;

    // Empty constructor
	public ImageMetaData(){
		
	}
	// constructor
	public ImageMetaData(int id, String name, String _coordinate_class, float _coordiante, byte _imageInByte[]){
		this._id = id;
		this._name = name;
		this._coordinate_class = _coordinate_class;
        this._coordiante = _coordiante;
        this._imageInByte = _imageInByte;
	}

    // constructor
    public ImageMetaData(int id, String name, String _coordinate_class, float _coordiante){
        this._id = id;
        this._name = name;
        this._coordinate_class = _coordinate_class;
        this._coordiante = _coordiante;
    }
	
	// constructor
	public ImageMetaData(String name, String _coordinate_class){
		this._name = name;
		this._coordinate_class = _coordinate_class;
	}
	// getting ID
	public int getID(){
		return this._id;
	}
	
	// setting id
	public void setID(int id){
		this._id = id;
	}
	
	// getting name
	public String getName(){
		return this._name;
	}
	
	// setting name
	public void setName(String name){
		this._name = name;
	}
	
	// getting image class
	public String getCoordinateClass(){
		return this._coordinate_class;
	}

    // setting image class
    public void setCoordinateClass(String image_class){
        this._coordinate_class = image_class;
    }
	
	// setting path coordiante
	public void setCoordinate(float path_coordinate){
		this._coordiante = path_coordinate;
	}

    // getting path coordiante
    public float getCoordinate(){
        return this._coordiante;
    }

    // setting image bytes
    public void setImageInByte(byte[] imageInByte){
        this._imageInByte = imageInByte;
    }

    // getting image bytes
    public byte[] getImageInByte(){
        return this._imageInByte;
    }


}
