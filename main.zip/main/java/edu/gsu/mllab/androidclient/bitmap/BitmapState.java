package edu.gsu.mllab.androidclient.bitmap;

public enum BitmapState {
    STARTED,
    SUCCESS,
    ERROR,
    SAVED,
}
