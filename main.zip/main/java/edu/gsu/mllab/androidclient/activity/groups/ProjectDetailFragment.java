package edu.gsu.mllab.androidclient.activity.groups;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import edu.gsu.mllab.androidclient.R;

/**
 * A fragment representing a single Item detail screen.
 * This fragment is contained in a {@link GroupsActivity}
 * in two-pane mode (on tablets)
 */
public class ProjectDetailFragment extends Fragment {

    /**
     * The fragment argument representing the item ID that this fragment
     * represents.
     */
    public static final String ARG_PROJECT_TITLE = "project_title";
    public static final String ARG_PROJECT_ABSTRACT = "project_abstract";

    public static boolean enableGetProject = false;

    /**
     * The dummy content this fragment is presenting.
     */
    private String project_abstract;
    private String project_title;

    private TextView tvProjectTitle;
    private TextView tvProjectAbstract;

    GroupsActivity activity;

    /**
     * Mandatory empty constructor for the fragment manager to instantiate the
     * fragment (e.g. upon screen orientation changes).
     */
    public ProjectDetailFragment() {
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (getArguments().containsKey(ARG_PROJECT_ABSTRACT) || getArguments().containsKey(ARG_PROJECT_TITLE)) {
            // Load the dummy content specified by the fragment
            // arguments. In a real-world scenario, use a Loader
            // to load content from a content provider.
            project_abstract = getArguments().getString(ARG_PROJECT_ABSTRACT);
            project_title = getArguments().getString(ARG_PROJECT_TITLE);
            ((GroupsActivity)getActivity()).getfragmentContainer().getBackground().setAlpha(40);
            activity = (GroupsActivity) this.getActivity();
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.project_detail_fragment, container, false);

        // Show the dummy content as text in a TextView.
        if (project_abstract != null) {
            tvProjectTitle =  ((TextView) rootView.findViewById(R.id.project_title));
            tvProjectTitle.setVisibility(View.VISIBLE);
            tvProjectTitle.setText(project_title);
            activity.btnGetItNow.setVisibility(View.VISIBLE);
            //Toast.makeText(getActivity(), project_title, Toast.LENGTH_SHORT).show();
        }

        if (project_abstract != null) {
            tvProjectAbstract =  ((TextView) rootView.findViewById(R.id.project_abstract));
            tvProjectAbstract.setVisibility(View.VISIBLE);
            tvProjectAbstract.setText(project_abstract);
            enableGetProject = true;
            activity.btnGetItNow.setVisibility(View.VISIBLE);
            //Toast.makeText(getActivity(), toastMsg, Toast.LENGTH_SHORT).show();
        }

        return rootView;
    }
}
