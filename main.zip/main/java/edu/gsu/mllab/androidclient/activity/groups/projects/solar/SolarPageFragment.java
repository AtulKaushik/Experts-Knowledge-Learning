package edu.gsu.mllab.androidclient.activity.groups.projects.solar;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import edu.gsu.mllab.androidclient.R;


public class SolarPageFragment extends Fragment {

    private int imageResource;
    private Bitmap bitmap;
    private static SolarCustomImageView mCustomImageView;

    public static SolarPageFragment getInstance(int resourceID) {
        SolarPageFragment f = new SolarPageFragment();
        Bundle args = new Bundle();
        args.putInt("image_source", resourceID);
        f.setArguments(args);
        return f;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        imageResource = getArguments().getInt("image_source");
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        return inflater.inflate(R.layout.solar_fragment_page, container, false);
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        mCustomImageView = (SolarCustomImageView) view.findViewById(R.id.solar_image);
        //TODO: Craeting shared pref for each image resource. Think of a better logic
        mCustomImageView.setPreferencesKey(Integer.toString(imageResource));

        BitmapFactory.Options o = new BitmapFactory.Options();
        o.inSampleSize = 4;
        o.inDither = false;
        bitmap = BitmapFactory.decodeResource(getResources(), imageResource, o);
        mCustomImageView.setImageBitmap(bitmap);

        mCustomImageView.mCurrentShape = SolarCustomImageView.SMOOTHLINE;
        mCustomImageView.reset();

    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        bitmap.recycle();
        bitmap = null;
    }

    /**
     * This method is being invoked from radio group buttons
     * @param checkedId
     */
    public void initializeCustomDrawing(int checkedId){
        switch (checkedId){
            case R.id.radioSmoothline:
                mCustomImageView.mCurrentShape = SolarCustomImageView.SMOOTHLINE;
                mCustomImageView.reset();
                break;
        }

    }

    public SolarCustomImageView getCustomImageView(){
        return mCustomImageView;
    }
}
