package edu.gsu.mllab.androidclient.view.customViews;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PorterDuff;
import android.support.v7.widget.AppCompatImageView;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

import edu.gsu.mllab.androidclient.data.model.Coordinate;

import static android.content.Context.MODE_PRIVATE;


/**
 * Created by mllab on 3/1/18.
 */

public class CustomImageView extends AppCompatImageView {

    public static final int LINE = 1;
    public static final int RECTANGLE = 3;
    public static final int SQUARE = 4;
    public static final int CIRCLE = 5;
    public static final int TRIANGLE = 6;
    public static final int SMOOTHLINE = 2;

    public static final float TOUCH_TOLERANCE = 4;
    public static final float TOUCH_STROKE_WIDTH = 5;

    public int mCurrentShape;

    protected Path mPath;
    //protected CustomPath mPath;
    protected ArrayList<Coordinate> coordinates;
    protected Coordinate coordinate;

    protected Paint mPaint;
    protected Paint mPaintFinal;
    protected Paint mRedrawPaint;

    protected Bitmap mBitmap;
    protected Canvas mCanvas;

    protected static Matrix mMatrix;
    protected static int mWidth;
    protected static int mHeight;
    private static MotionEvent mMotionEvent;

    private SharedPreferences  mPreferences;
    private String  mPreferencesKey;

    /**
     * Indicates if you are drawing
     */
    protected boolean isDrawing = false;

    /**
     * Indicates if the drawing is ended
     */
    protected boolean isDrawingEnded = false;

    //flag to enable/disable drawing
    protected static boolean drawingEnabled = false;


    protected float mStartX;
    protected float mStartY;

    protected float mx;
    protected float my;

    public CustomImageView(Context context) {
        super(context);
        // TODO Auto-generated constructor stub
        setBackgroundColor(Color.WHITE);
        init();

    }

    public CustomImageView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    public CustomImageView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();
    }

    @Override
    protected void onLayout(boolean changed, int l, int t, int r, int b) {

    }

    //private static final String COORDINATES_REPO = "cooordiantes_repo3";


    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        mBitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        mCanvas = new Canvas(mBitmap);

        //TODO: This is the logic to draw any previosly saved path coordinates
        //This method will be called several times during the initialization
        coordinates = retrievePathCoordinates(); //method may return null, if there's no saved path coordinates
        if(coordinates != null && !coordinates.isEmpty()){

            mPath.reset();
            for (Coordinate coordinate : coordinates){

               mPath.moveTo(coordinate.getX().floatValue(), coordinate.getY().floatValue());
                mPath.lineTo(coordinate.getX().floatValue(), coordinate.getY().floatValue());
            }

            mCanvas.drawPath(mPath, mRedrawPaint);
            mPath.reset();
            invalidate();

        }
    }


    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        canvas.drawBitmap(mBitmap, 0, 0, mPaint);

        if (isDrawing){
            switch (mCurrentShape) {
                case LINE:
                    onDrawLine(canvas);
                    break;
                case RECTANGLE:
                    onDrawRectangle(canvas);
                    break;
                case SQUARE:
                    onDrawSquare(canvas);
                    break;
                case CIRCLE:
                    onDrawCircle(canvas);
                    break;
                case TRIANGLE:
                    onDrawTriangle(canvas);
                    break;
            }
        }
    }




    protected void init() {
        mPath = new Path();

        // Setup paint and attributes for any moving action
        mPaint = new Paint(Paint.DITHER_FLAG);
        mPaint.setAntiAlias(true);
        mPaint.setDither(true);
        mPaint.setColor(getContext().getResources().getColor(android.R.color.holo_green_dark));
        mPaint.setStyle(Paint.Style.STROKE);
        mPaint.setStrokeJoin(Paint.Join.ROUND);
        mPaint.setStrokeCap(Paint.Cap.ROUND);
        mPaint.setStrokeWidth(TOUCH_STROKE_WIDTH);

        // Setup paint and attributes for any up action
        mPaintFinal = new Paint(Paint.DITHER_FLAG);
        mPaintFinal.setAntiAlias(true);
        mPaintFinal.setDither(true);
        mPaintFinal.setColor(getContext().getResources().getColor(android.R.color.holo_blue_dark));
        mPaintFinal.setStyle(Paint.Style.STROKE);
        mPaintFinal.setStrokeJoin(Paint.Join.ROUND);
        mPaintFinal.setStrokeCap(Paint.Cap.ROUND);
        mPaintFinal.setStrokeWidth(TOUCH_STROKE_WIDTH);

        // Setup paint and attributes for any redrawing
        mRedrawPaint = new Paint(Paint.DITHER_FLAG);
        mRedrawPaint.setStyle(Paint.Style.FILL);
        mRedrawPaint.setStyle(Paint.Style.STROKE);
        mRedrawPaint.setStrokeWidth(12);
        mRedrawPaint.setColor(getContext().getResources().getColor(android.R.color.holo_orange_light));
        mRedrawPaint.setStrokeJoin(Paint.Join.ROUND);
        mRedrawPaint.setStrokeCap(Paint.Cap.ROUND);


        mPreferences = getContext().getSharedPreferences("CustomPaths", MODE_PRIVATE);
    }

    public void reset() {
        mPath = new Path();
        //mPath = new CustomPath();
        countTouch=0;
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        //ACTION_MOVE = 2, ACTION_UP = 1
        Log.i("onTouchEvent", ""+event.getAction());
        if(drawingEnabled){
            mx = event.getX();
            my = event.getY();

            switch (mCurrentShape) {
                case LINE:
                    onTouchEventLine(event);
                    break;
                case SMOOTHLINE:
                    onTouchEventSmoothLine(event);
                    break;
                case RECTANGLE:
                    onTouchEventRectangle(event);
                    break;
                case SQUARE:
                    onTouchEventSquare(event);
                    break;
                case CIRCLE:
                    onTouchEventCircle(event);
                    break;
                case TRIANGLE:
                    onTouchEventTriangle(event);
                    break;
            }
            return true;
        }
        return false;
    }



    //------------------------------------------------------------------
    // Line
    //------------------------------------------------------------------

    private void onDrawLine(Canvas canvas) {

        float dx = Math.abs(mx - mStartX);
        float dy = Math.abs(my - mStartY);
        if (dx >= TOUCH_TOLERANCE || dy >= TOUCH_TOLERANCE) {
            canvas.drawLine(mStartX, mStartY, mx, my, mPaint);
        }
    }

    private void onTouchEventLine(MotionEvent event) {

        switch (event.getAction()) {
            case MotionEvent.ACTION_DOWN:
                isDrawing = true;
                mStartX = mx;
                mStartY = my;
                invalidate();
                break;
            case MotionEvent.ACTION_MOVE:
                invalidate();
                break;
            case MotionEvent.ACTION_UP:
                isDrawing = false;
                mCanvas.drawLine(mStartX, mStartY, mx, my, mPaintFinal);
                invalidate();
                break;
        }
    }

    //------------------------------------------------------------------
    // Smooth Line / Freehand
    //------------------------------------------------------------------


    private void onTouchEventSmoothLine(MotionEvent event) {
        coordinates = (coordinates == null)? new ArrayList<Coordinate>():coordinates;
        coordinates.add(new Coordinate((double)mx, (double)my));

        switch (event.getAction()) {
            case MotionEvent.ACTION_DOWN:

                isDrawing = true;
                mStartX = mx;
                mStartY = my;

                mPath.reset();
                mPath.moveTo(mx, my);
                Log.i("::ACTION_DOWN::", mStartX +" // " +mStartY);
                invalidate();
                break;
            case MotionEvent.ACTION_MOVE:

                float dx = Math.abs(mx - mStartX);
                float dy = Math.abs(my - mStartY);
                if (dx >= TOUCH_TOLERANCE || dy >= TOUCH_TOLERANCE) {
                    mPath.quadTo(mStartX, mStartY, (mx + mStartX) / 2, (my + mStartY) / 2);
                    mStartX = mx;
                    mStartY = my;
                }
                mCanvas.drawPath(mPath, mPaint);
                Log.i("::ACTION_MOVE::", mStartX +" // " +mStartY);
                invalidate();
                break;
            case MotionEvent.ACTION_UP:
                isDrawing = false;
                mPath.lineTo(mStartX, mStartY);
                Log.i("::ACTION_UP::", mStartX +" // " +mStartY);
                mCanvas.drawPath(mPath, mPaintFinal);
                mPath.reset();
                invalidate();
                saveCustomPath(coordinates);
                coordinates.clear();
                break;
        }
    }

    //------------------------------------------------------------------
    // Triangle
    //------------------------------------------------------------------

    int countTouch =0;
    float basexTriangle =0;
    float baseyTriangle =0;

    private void onDrawTriangle(Canvas canvas){

        if (countTouch<3){
            canvas.drawLine(mStartX,mStartY,mx,my,mPaint);
        }else if (countTouch==3){
            canvas.drawLine(mx,my,mStartX,mStartY,mPaint);
            canvas.drawLine(mx,my,basexTriangle,baseyTriangle,mPaint);
        }
    }

    private void onTouchEventTriangle(MotionEvent event) {

        switch (event.getAction()) {
            case MotionEvent.ACTION_DOWN:
                countTouch++;
                if (countTouch==1){
                    isDrawing = true;
                    mStartX = mx;
                    mStartY = my;
                } else if (countTouch==3){
                    isDrawing = true;
                }
                invalidate();
                break;
            case MotionEvent.ACTION_MOVE:
                invalidate();
                break;
            case MotionEvent.ACTION_UP:
                countTouch++;
                isDrawing = false;
                if (countTouch<3){
                    basexTriangle=mx;
                    baseyTriangle=my;
                    mCanvas.drawLine(mStartX,mStartY,mx,my,mPaintFinal);
                } else if (countTouch>=3){
                    mCanvas.drawLine(mx,my,mStartX,mStartY,mPaintFinal);
                    mCanvas.drawLine(mx,my,basexTriangle,baseyTriangle,mPaintFinal);
                    countTouch =0;
                }
                invalidate();
                break;
        }
    }

    //------------------------------------------------------------------
    // Circle
    //------------------------------------------------------------------

    private void onDrawCircle(Canvas canvas){
        canvas.drawCircle(mStartX, mStartY, calculateRadius(mStartX, mStartY, mx, my), mPaint);
    }

    private void onTouchEventCircle(MotionEvent event) {
        switch (event.getAction()) {
            case MotionEvent.ACTION_DOWN:
                isDrawing = true;
                mStartX = mx;
                mStartY = my;
                invalidate();
                break;
            case MotionEvent.ACTION_MOVE:
                invalidate();
                break;
            case MotionEvent.ACTION_UP:
                isDrawing = false;
                mCanvas.drawCircle(mStartX, mStartY, calculateRadius(mStartX,mStartY,mx,my), mPaintFinal);
                invalidate();
                break;
        }
    }

    /**
     *
     * @return
     */
    protected float calculateRadius(float x1, float y1, float x2, float y2) {

        return (float) Math.sqrt(
                Math.pow(x1 - x2, 2) +
                        Math.pow(y1 - y2, 2)
        );
    }

    //------------------------------------------------------------------
    // Rectangle
    //------------------------------------------------------------------

    private void onDrawRectangle(Canvas canvas) {
        drawRectangle(canvas,mPaint);
    }

    private void onTouchEventRectangle(MotionEvent event) {

        switch (event.getAction()) {
            case MotionEvent.ACTION_DOWN:
                isDrawing = true;
                mStartX = mx;
                mStartY = my;
                invalidate();
                break;
            case MotionEvent.ACTION_MOVE:
                invalidate();
                break;
            case MotionEvent.ACTION_UP:
                isDrawing = false;
                drawRectangle(mCanvas,mPaintFinal);
                invalidate();
                break;
        }
        ;
    }

    private void drawRectangle(Canvas canvas,Paint paint){
        float right = mStartX > mx ? mStartX : mx;
        float left = mStartX > mx ? mx : mStartX;
        float bottom = mStartY > my ? mStartY : my;
        float top = mStartY > my ? my : mStartY;
        canvas.drawRect(left, top , right, bottom, paint);
    }

    //------------------------------------------------------------------
    // Square
    //------------------------------------------------------------------

    private void onDrawSquare(Canvas canvas) {
        onDrawRectangle(canvas);
    }

    private void onTouchEventSquare(MotionEvent event) {

        switch (event.getAction()) {
            case MotionEvent.ACTION_DOWN:
                isDrawing = true;
                mStartX = mx;
                mStartY = my;
                invalidate();
                break;
            case MotionEvent.ACTION_MOVE:
                adjustSquare(mx, my);
                invalidate();
                break;
            case MotionEvent.ACTION_UP:
                isDrawing = false;
                adjustSquare(mx, my);
                drawRectangle(mCanvas,mPaintFinal);
                invalidate();
                break;
        }
    }

    /**
     * Adjusts current coordinates to build a square
     * @param x
     * @param y
     */
    protected void adjustSquare(float x, float y) {
        float deltaX = Math.abs(mStartX - x);
        float deltaY = Math.abs(mStartY - y);

        float max = Math.max(deltaX, deltaY);

        mx = mStartX - x < 0 ? mStartX + max : mStartX - max;
        my = mStartY - y < 0 ? mStartY + max : mStartY - max;
    }

    public void clearCanvas(){
        invalidate();
        mPath.reset();
        mCanvas.drawColor(Color.TRANSPARENT, PorterDuff.Mode.CLEAR);
    }

    public void setDrawingEnabled(boolean drawingEnabled) {
        this.drawingEnabled = drawingEnabled;
    }

    public boolean isDrawingEnabled() {
        return drawingEnabled;
    }


    public void saveCustomPath(ArrayList<Coordinate> coordinates){
        SharedPreferences.Editor prefsEditor = mPreferences.edit();

        //TODO: Hashset doesn't maintain the order, therefore redrwaing points will clutter the image. Fix this on a later stage.
        Set<String> set= new HashSet<String>();
        for (int i = 0; i < coordinates.size(); i++) {
            set.add(coordinates.get(i).getJSONObject().toString());
        }

        prefsEditor.putStringSet(mPreferencesKey, set);
        prefsEditor.commit();
        Log.i("saveCustomPath", set.toString());
    }

    public ArrayList<Coordinate> retrievePathCoordinates(){

            ArrayList<Coordinate> savedCoordinates = new ArrayList<Coordinate>();

            Set<String> set = mPreferences.getStringSet(mPreferencesKey, null);
            if (set != null) {
                for (String s : set) {
                    try {
                        JSONObject jsonObject = new JSONObject(s);
                        Double x = jsonObject.getDouble("x");
                        Double y = jsonObject.getDouble("y");
                        Coordinate coordinate = new Coordinate(x, y);

                        savedCoordinates.add(coordinate);

                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
                Log.i("retrieveCustomPath", set.toString());
                return savedCoordinates;
            }
        return null;
    }

    public void setPreferencesKey(String preferencesKey){
        this.mPreferencesKey = preferencesKey;
    }

}