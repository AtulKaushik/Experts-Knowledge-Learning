package edu.gsu.mllab.androidclient.activity.groups.projects.sample;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Paint;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import edu.gsu.mllab.androidclient.R;
import edu.gsu.mllab.androidclient.Utils.Constants;

public class SamplePageFragment extends Fragment {

    private int imageResource;
    private int imagePosition;
    private Bitmap bitmap;
    private static SampleCustomImageView mCustomImageView;
    private static String TAG = SamplePageFragment.class.getSimpleName();

    public static SamplePageFragment getInstance(int resourceID, int position) {
        SamplePageFragment f = new SamplePageFragment();
        Bundle args = new Bundle();
        args.putInt("image_source", resourceID);
        args.putInt("image_position", position);
        f.setArguments(args);
        return f;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        imageResource = getArguments().getInt("image_source");
        imagePosition = getArguments().getInt("image_position");
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        return inflater.inflate(R.layout.sample_fragment_page, container, false);
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        mCustomImageView = (SampleCustomImageView) view.findViewById(R.id.sample_image);

        BitmapFactory.Options o = new BitmapFactory.Options();
        o.inSampleSize = 4;
        o.inDither = false;
        bitmap = BitmapFactory.decodeResource(getResources(), imageResource, o);
        mCustomImageView.setImageBitmap(bitmap);

        mCustomImageView.mCurrentShape = SampleCustomImageView.SMOOTHLINE;
        mCustomImageView.reset();

        mCustomImageView.setPreferencesKey(Constants.PROJECT_IDENTIFIER_SAMPLE+imagePosition);
        Log.i(TAG, "Current fragments SHARED PREF = "+Constants.PROJECT_IDENTIFIER_SAMPLE+imagePosition);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        bitmap.recycle();
        bitmap = null;
    }

    /**
     * This method is being invoked from radio group buttons
     * @param checkedId
     */
    public void initializeCustomDrawing(int checkedId){
        switch (checkedId){
            case R.id.radioLine:
                mCustomImageView.mCurrentShape = SampleCustomImageView.LINE;
                mCustomImageView.reset();
                break;
            case R.id.radioSmoothline:
                mCustomImageView.mCurrentShape = SampleCustomImageView.SMOOTHLINE;
                mCustomImageView.reset();
                break;
            case R.id.radioRectangle:
                mCustomImageView.mCurrentShape = SampleCustomImageView.RECTANGLE;
                mCustomImageView.reset();
                break;
            case R.id.radioSquare:
                mCustomImageView.mCurrentShape = SampleCustomImageView.SQUARE;
                mCustomImageView.reset();
                break;
            case R.id.radioCircle:
                mCustomImageView.mCurrentShape = SampleCustomImageView.CIRCLE;
                mCustomImageView.reset();
                break;
            case R.id.radioTriangle:
                mCustomImageView.mCurrentShape = SampleCustomImageView.TRIANGLE;
                mCustomImageView.reset();
                break;

        }

    }

    public SampleCustomImageView getCustomImageView(){
        return mCustomImageView;
    }

    private Paint setupPaint(int width, int color) {
        Paint paint = new Paint();
        paint.setAntiAlias(true);
        paint.setDither(true);
        paint.setColor(color);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeJoin(Paint.Join.ROUND);
        paint.setStrokeCap(Paint.Cap.ROUND);
        paint.setStrokeWidth(width);
        return paint;
    }
}
