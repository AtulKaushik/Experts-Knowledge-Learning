package edu.gsu.mllab.androidclient.data.remote;

/**
 * Created by mllab on 1/18/18.
 */

import edu.gsu.mllab.androidclient.data.model.Group;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.http.*;

public interface Services {
    @POST("post")
    Call<Group> addBook(@Body Group group);

}
