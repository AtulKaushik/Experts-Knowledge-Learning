package edu.gsu.mllab.androidclient.view.adapters;

import android.content.Context;
import android.graphics.Bitmap;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.animation.GlideAnimation;
import com.bumptech.glide.request.target.SimpleTarget;
import com.davemorrissey.labs.subscaleview.ImageSource;
import com.davemorrissey.labs.subscaleview.SubsamplingScaleImageView;

import java.util.ArrayList;

import edu.gsu.mllab.androidclient.R;

/**
 * Created by mllab on 3/1/18.
 */

public class SlidingImageAdapter extends PagerAdapter {

    Context _context;
    LayoutInflater _inflater;
    private ArrayList<String> _images;
    private LinearLayout _thumbnails;
    ViewPager _pager;
    private String TAG = SlidingImageAdapter.class.getSimpleName();

    public SlidingImageAdapter(Context context, ArrayList<String> _images, LinearLayout _thumbnails, ViewPager _pager) {
        this._context = context;
        this._images = _images;
        this._thumbnails = _thumbnails;
        this._pager = _pager;
        this._inflater = (LayoutInflater) _context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public int getCount() {
        return _images.size();
    }

    @Override
    public boolean isViewFromObject(View view, Object object) {
        return view == ((LinearLayout) object);
    }

    @Override
    public Object instantiateItem(ViewGroup container, final int position) {
        View itemView = _inflater.inflate(R.layout.pager_gallery_item, container, false);
        container.addView(itemView);

        // Get the border size to show around each image
        int borderSize = _thumbnails.getPaddingTop();

        // Get the size of the actual thumbnail image
        int thumbnailSize = ((FrameLayout.LayoutParams)
                _pager.getLayoutParams()).bottomMargin - (borderSize*2);

        // Set the thumbnail layout parameters. Adjust as required
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(thumbnailSize, thumbnailSize);
        params.setMargins(0, 0, borderSize, 0);

        // You could also set like so to remove borders
        //ViewGroup.LayoutParams params = new ViewGroup.LayoutParams(
        //        ViewGroup.LayoutParams.WRAP_CONTENT,
        //        ViewGroup.LayoutParams.WRAP_CONTENT);

        final ImageView thumbView = new ImageView(_context);
        thumbView.setScaleType(ImageView.ScaleType.CENTER_CROP);
        thumbView.setLayoutParams(params);
        thumbView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d(TAG, "Thumbnail clicked");
                //Toast.makeText(_context, "Page Clicked : "+position, Toast.LENGTH_LONG).show();
                // Set the pager position when thumbnail clicked
                _pager.setCurrentItem(position);
            }
        });

        _thumbnails.addView(thumbView);

        /**
         TextView page = new TextView(_context);
         page.setLayoutParams(params);
         page.setPadding(1, 1, 1, 1);
         page.setTypeface(Typeface.DEFAULT_BOLD);

         page.setGravity(Gravity.CENTER);
         page.setText(Integer.toString(position));
         _pageNumber.addView(page);
         */

        final SubsamplingScaleImageView imageView =
                (SubsamplingScaleImageView) itemView.findViewById(R.id.image);

        // Asynchronously load the image and set the thumbnail and pager view
        Glide.with(_context)
                .load(_images.get(position))
                .asBitmap()
                .into(new SimpleTarget<Bitmap>() {
                    @Override
                    public void onResourceReady(Bitmap bitmap, GlideAnimation anim) {
                        imageView.setImage(ImageSource.bitmap(bitmap));
                        thumbView.setImageBitmap(bitmap);
                    }
                });

        return itemView;
    }

    @Override
    public void destroyItem(ViewGroup container, int position, Object object) {
        container.removeView((LinearLayout) object);
    }
}
