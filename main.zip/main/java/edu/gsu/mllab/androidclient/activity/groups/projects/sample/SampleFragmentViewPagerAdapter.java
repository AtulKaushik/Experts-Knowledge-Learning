package edu.gsu.mllab.androidclient.activity.groups.projects.sample;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentStatePagerAdapter;

import java.util.List;

public class SampleFragmentViewPagerAdapter extends FragmentStatePagerAdapter {

    private List<Integer> images;

    public SampleFragmentViewPagerAdapter(FragmentManager fm, List<Integer> imagesList) {
        super(fm);
        this.images = imagesList;
    }

    @Override
    public Fragment getItem(int position) {
        return SamplePageFragment.getInstance(images.get(position),position);
    }

    @Override
    public int getCount() {
        return images.size();
    }

}
