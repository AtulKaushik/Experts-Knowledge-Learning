package edu.gsu.mllab.androidclient.data.model;

public class SubCategory {

    private String name; //project name
    public String id; //project id
    public String content; //Project abstract
    private String description; //Short description

    public SubCategory(String itemId, String name, String description, String content) {
        super();
        this.id = id;
        this.name = name;
        this.description = description;
        this.content = content;
    }

    public SubCategory(String name) {
        super();
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

}
