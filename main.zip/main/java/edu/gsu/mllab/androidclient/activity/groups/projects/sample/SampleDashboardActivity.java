package edu.gsu.mllab.androidclient.activity.groups.projects.sample;

import android.annotation.SuppressLint;
import android.content.ActivityNotFoundException;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.GestureDetector;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.RelativeLayout;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import edu.gsu.mllab.androidclient.R;
import edu.gsu.mllab.androidclient.Utils.Constants;
import edu.gsu.mllab.androidclient.bitmap.BitmapInput;
import edu.gsu.mllab.androidclient.bitmap.BitmapUtils;
import edu.gsu.mllab.androidclient.view.recyclerView.base.root.ExpandableRecyclerAdapter;
import edu.gsu.mllab.androidclient.data.model.Category;
import edu.gsu.mllab.androidclient.data.model.SubCategory;

public class SampleDashboardActivity extends AppCompatActivity implements View.OnClickListener{

    private ArrayList<Integer> images;
    private BitmapFactory.Options options;
    private SampleCustomViewPager viewPager;
    private View btnNext, btnPrev;
    private SampleFragmentViewPagerAdapter adapter;
    private LinearLayout thumbnailsContainer;

    private Category mCurrentCategory;
    private String mCurrentSubcategory;

    //Buttons
    private ImageButton buttonPencil;

    //Custom Drawing
    private RadioGroup radioGroup1;
    int chkId1;
    private RadioButton radioClassOne;
    private RadioButton radioClassTwo;
    private RadioButton radioClassThree;
    //Keeping a track of classes created, max 3 allowed
    private static int classes = 0;

    //keep track of camera capture intent
    final int CAMERA_CAPTURE = 1;

    private final String TAG = SampleDashboardActivity.class.getSimpleName();

    //UP & Down Gesture
    private GestureDetector gesturedetector = null;
    RelativeLayout pagerContainer;

    private String mPreferencesKey;


    //RecyclerView
    private SampleAdapter mAdapter;
    private RecyclerView recyclerView;

    private final static int[] resourceIDs = new int[]{R.mipmap.sample_image, R.mipmap.sample_image,
            R.mipmap.sample_image, R.mipmap.sample_image, R.mipmap.sample_image, R.mipmap.sample_image, R.mipmap.sample_image, R.mipmap.sample_image, R.mipmap.sample_image, R.mipmap.sample_image, R.mipmap.sample_image, R.mipmap.sample_image, R.mipmap.sample_image, R.mipmap.sample_image, R.mipmap.sample_image, R.mipmap.sample_image};

    @SuppressLint("ClickableViewAccessibility")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sample_dashboard);

        //TODO: Setting preferences key for saving coordiantes under this category (shared pref name is category name right now)
        setSharedPrefKey(getIntent().getExtras().getString("prefs"));


        BottomNavigationView bottomNavigationView = (BottomNavigationView)
                findViewById(R.id.bottomNavigation);

        images = new ArrayList<>();

        //find view by id
        viewPager = (SampleCustomViewPager) findViewById(R.id.view_pager);
        thumbnailsContainer = (LinearLayout) findViewById(R.id.container);
        btnNext = findViewById(R.id.next);
        btnPrev = findViewById(R.id.prev);

        buttonPencil = findViewById(R.id.btn_pencil);

        pagerContainer = (RelativeLayout) findViewById(R.id.view_pager_container);

        buttonPencil.setOnClickListener(this);
        btnPrev.setOnClickListener(onClickListener(0));
        btnNext.setOnClickListener(onClickListener(1));

        setImagesData();

        // init viewpager adapter and attach
        adapter = new SampleFragmentViewPagerAdapter(getSupportFragmentManager(), images);
        viewPager.setAdapter(adapter);

        inflateThumbnails();

        //viewPager.setOn
        gesturedetector = new GestureDetector(new MyGestureListenerSample());
        pagerContainer.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                gesturedetector.onTouchEvent(event);
                return true;
            }

        });


        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                SamplePageFragment samplePageFragment = (SamplePageFragment) adapter.getItem(viewPager.getCurrentItem());

                switch (item.getItemId()) {
                    case R.id.action_home:
                        Toast.makeText(SampleDashboardActivity.this, "action_home", Toast.LENGTH_LONG).show();
                        break;

                    case R.id.action_save:
                        //Toast.makeText(SampleDashboardActivity.this, mCurrentCategory+"_"+mCurrentSubcategory+"_"+viewPager.getCurrentItem(), Toast.LENGTH_LONG).show();


                        //setSharedPrefKey(Constants.PROJECT_IDENTIFIER_SAMPLE+viewPager.getCurrentItem());
                            samplePageFragment.getCustomImageView().savePathCoordinates();

                        //takeScreenshot();
                        break;

                    case R.id.action_camera:
                        Toast.makeText(SampleDashboardActivity.this, "action_camera", Toast.LENGTH_LONG).show();
                        startCamera();
                        break;

                    case R.id.action_undo:
                        Toast.makeText(SampleDashboardActivity.this, "sample_action_undo", Toast.LENGTH_LONG).show();
                        //SamplePageFragment samplePageFragment = (SamplePageFragment) adapter.getItem(viewPager.getCurrentItem());
                        samplePageFragment.getCustomImageView().clearPathCoordinates();
                        //samplePageFragment.getCustomImageView().refreshDrawableState();
                        //samplePageFragment.getCustomImageView().clearCanvas();


                        android.support.v4.app.FragmentTransaction fragTransaction =   getSupportFragmentManager().beginTransaction();
                        fragTransaction.detach(samplePageFragment);
                        fragTransaction.attach(samplePageFragment);
                        fragTransaction.commit();
                        //adapter.notifyDataSetChanged();
                        //samplePageFragment.getCustomImageView().invalidate();

                        break;
                }
                return true;
            }
        });

        //Recyclerview code
        //Getting master-detail child views (subcategories under categories)
        SubCategory subCategory_one = new SubCategory("Subcategory -1");
        SubCategory subCategory_two = new SubCategory("Subcategory -2");
        SubCategory subCategory_three = new SubCategory("Subcategory -3");
        SubCategory subCategory_four = new SubCategory("Subcategory -4");
        SubCategory subCategory_five = new SubCategory("Subcategory -5");
        SubCategory subCategory_six = new SubCategory("Subcategory -6");
        SubCategory subCategory_seven = new SubCategory("Subcategory -7");
        SubCategory subCategory_eight = new SubCategory("Subcategory -8");
        SubCategory subCategory_nine = new SubCategory("Subcategory -9");
        SubCategory subCategory_ten = new SubCategory("Subcategory -10");
        SubCategory subCategory_eleven = new SubCategory("Subcategory -11");
        SubCategory subCategory_tweleve = new SubCategory("Subcategory -12");

        //master categories
        Category category_one = new Category("Categor-1", Arrays.asList(subCategory_one, subCategory_two, subCategory_three));
        Category category_two = new Category("Category-2", Arrays.asList(subCategory_four, subCategory_five));
        Category category_three = new Category("Category-3", Arrays.asList(subCategory_six, subCategory_seven, subCategory_eight, subCategory_nine));
        Category category_four = new Category("Category-4", Arrays.asList(subCategory_ten, subCategory_eleven, subCategory_tweleve));

        final List<Category> sampleCategories = Arrays.asList(category_one, category_two, category_three, category_four);

        recyclerView = (RecyclerView) findViewById(R.id.recyclerview);
        mAdapter = new SampleAdapter(this, sampleCategories);
        mAdapter.setExpandCollapseListener(new ExpandableRecyclerAdapter.ExpandCollapseListener() {
            @Override
            public void onListItemExpanded(int position) {
                mCurrentCategory = sampleCategories.get(position);

                String toastMsg = getResources().getString(R.string.expanded, mCurrentCategory.getName());
                Toast.makeText(SampleDashboardActivity.this, toastMsg, Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onListItemCollapsed(int position) {
                mCurrentCategory = sampleCategories.get(position);

                String toastMsg = getResources().getString(R.string.collapsed, mCurrentCategory.getName());
                Toast.makeText(SampleDashboardActivity.this, toastMsg, Toast.LENGTH_SHORT).show();
            }
        });

        recyclerView.setAdapter(mAdapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        //Custom Drawing
        radioGroup1 = (RadioGroup) findViewById(R.id.radioGroup1);

        //TODO: Change names for theses buttons, they are just flags on up-swipe
        radioClassOne = (RadioButton) findViewById(R.id.radioLine);
        radioClassTwo = (RadioButton) findViewById(R.id.radioSmoothline);
        radioClassThree = (RadioButton) findViewById(R.id.radioRectangle);


        chkId1 = radioGroup1.getCheckedRadioButtonId();

        //TODO: Seems unnecessary
        //radioGroup1.clearCheck(); // this is so we can start fresh, with no selection on RadioGroup
        // Checked change Listener for RadioGroup 1
        radioGroup1.setOnCheckedChangeListener(listener1);
        //above this, end of onCreate method
    }

    public boolean dispatchTouchEvent(MotionEvent ev) {

        super.dispatchTouchEvent(ev);

        return gesturedetector.onTouchEvent(ev);

    }

    private View.OnClickListener onClickListener(final int i) {
        return new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (i > 0) {
                    //next page
                    if (viewPager.getCurrentItem() < viewPager.getAdapter().getCount() - 1) {
                        viewPager.setCurrentItem(viewPager.getCurrentItem() + 1);
                    }
                } else {
                    //previous page
                    if (viewPager.getCurrentItem() > 0) {
                        viewPager.setCurrentItem(viewPager.getCurrentItem() - 1);
                    }
                }
            }
        };
    }

    private void setImagesData() {
        for (int i = 0; i < resourceIDs.length; i++) {
            images.add(resourceIDs[i]);
        }
    }

    private void inflateThumbnails() {
        for (int i = 0; i < images.size(); i++) {
            View imageLayout = getLayoutInflater().inflate(R.layout.item_image, null);
            ImageView imageView = (ImageView) imageLayout.findViewById(R.id.img_thumb);
            imageView.setOnClickListener(onChagePageClickListener(i));
            options = new BitmapFactory.Options();
            options.inSampleSize = 3;
            options.inDither = false;
            Bitmap bitmap = BitmapFactory.decodeResource(getResources(), images.get(i), options);
            imageView.setImageBitmap(bitmap);
            //set to image view
            imageView.setImageBitmap(bitmap);
            //add imageview
            thumbnailsContainer.addView(imageLayout);
        }
    }

    private View.OnClickListener onChagePageClickListener(final int i) {
        return new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                viewPager.setCurrentItem(i);
            }
        };
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        mAdapter.onSaveInstanceState(outState);
    }

    @Override
    protected void onRestoreInstanceState(Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);
        mAdapter.onRestoreInstanceState(savedInstanceState);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId() /*to get clicked view id**/) {
            case R.id.btn_pencil:
                if(buttonPencil.isSelected()){
                    buttonPencil.setSelected(false);
                }else{
                    buttonPencil.setSelected(true);
                }
                SamplePageFragment samplePageFragment = (SamplePageFragment) adapter.getItem(viewPager.getCurrentItem());
                SampleCustomImageView customImageView = samplePageFragment.getCustomImageView();

                if(viewPager.getPagingEnabled()){
                    viewPager.setPagingEnabled(false);
                    if(!customImageView.isDrawingEnabled()){
                        customImageView.setDrawingEnabled(true);
                        Toast.makeText(SampleDashboardActivity.this, "Freehand Drawing Activated", Toast.LENGTH_LONG).show();
                    }
                } else {
                    viewPager.setPagingEnabled(true);
                    if(customImageView.isDrawingEnabled()){
                        customImageView.setDrawingEnabled(false);
                    }
                }
                break;
            default:
                break;
        }
    }

    /**
     * Listener for UP/DOWN/LEFT/RIGHT events
     */
    class MyGestureListenerSample extends SampleOnSwipeListener {

        private static final int SWIPE_MIN_DISTANCE = 150;

        private static final int SWIPE_MAX_OFF_PATH = 100;

        private static final int SWIPE_THRESHOLD_VELOCITY = 100;

        @Override

        public boolean onFling(MotionEvent e1, MotionEvent e2, float velocityX, float velocityY) {

            float dX = e2.getX() - e1.getX();
            float dY = e1.getY() - e2.getY();

            if (Math.abs(dY) < SWIPE_MAX_OFF_PATH &&
                    Math.abs(velocityX) >= SWIPE_THRESHOLD_VELOCITY &&
                    Math.abs(dX) >= SWIPE_MIN_DISTANCE) {

                if (dX > 0) {
                    Toast.makeText(SampleDashboardActivity.this, "right swipe", Toast.LENGTH_LONG).show();
                } else {
                    Toast.makeText(SampleDashboardActivity.this, "left swipe", Toast.LENGTH_LONG).show();
                }
                return true;
            } else if (Math.abs(dX) < SWIPE_MAX_OFF_PATH &&
                    Math.abs(velocityY) >= SWIPE_THRESHOLD_VELOCITY &&
                    Math.abs(dY) >= SWIPE_MIN_DISTANCE) {

                if (dY > 0) {
                    //For Dialog
                    if(!buttonPencil.isSelected()){
                    if (classes <3){
                        //Toast.makeText(SampleDashboardActivity.this, "classes = "+ classes, Toast.LENGTH_LONG).show();
                        getDialog();
                    }else{
                        Toast.makeText(SampleDashboardActivity.this, "You can create maximum 3 classes", Toast.LENGTH_LONG).show();
                    }}
                    //Toast.makeText(SampleDashboardActivity.this, "up swipe", Toast.LENGTH_LONG).show();
                } else {
                    Toast.makeText(SampleDashboardActivity.this, "down swipe", Toast.LENGTH_LONG).show();
                }
                return true;
            }
            return false;
        }
    }

    // Custom Drawing
    /**
     * This method is being invoked from radio group buttons
     * @param checkedId
     */
    public void initCustomDrawing(int checkedId){
        SamplePageFragment page =  (SamplePageFragment) adapter.getItem(viewPager.getCurrentItem());//(SamplePageFragment) getSupportFragmentManager().findFragmentByTag("android:switcher:" + R.id.view_pager + ":" + viewPager.getCurrentItem());
        // based on the current position you can then cast the page to the correct
        //TODO: these toasts are not needed
        //Toast.makeText(getApplicationContext(), "Current Item= "+viewPager.getCurrentItem(), Toast.LENGTH_SHORT).show();
        //Toast.makeText(getApplicationContext(), "page fragment= "+page, Toast.LENGTH_SHORT).show();
        if (page != null) {
            //Toast.makeText(getApplicationContext(), "page tag= "+page.getTag(), Toast.LENGTH_SHORT).show();
            page.initializeCustomDrawing(checkedId);
        }

    }

    private RadioGroup.OnCheckedChangeListener listener1 = new RadioGroup.OnCheckedChangeListener() {

        @Override
        public void onCheckedChanged(RadioGroup group, int checkedId) {
            if (checkedId != -1) {
                initCustomDrawing(checkedId);
                switch (checkedId) {
                    case R.id.radioLine:
                        Toast.makeText(getApplicationContext(), "Line RadioButton checked", Toast.LENGTH_SHORT).show();
                        break;
                    case R.id.radioSmoothline:
                        //uncheckRadios(R.id.radioGroup1, radioClassTwo);
                        //Toast.makeText(getApplicationContext(), "Smoothline RadioButton checked", Toast.LENGTH_SHORT).show();
                        break;
                    case R.id.radioRectangle:
                        //uncheckRadios(R.id.radioGroup1, radioClassThree);
                        Toast.makeText(getApplicationContext(), "Rectangle RadioButton checked", Toast.LENGTH_SHORT).show();
                        break;
                    default:
                        break;
                }
            }
        }
    };

    //Bottom navigationbar functions

    public Bitmap takeScreenshot() {
        View rootView = pagerContainer;//mCustomShapeFragment.getView();
        rootView.setDrawingCacheEnabled(true);
        //return rootView.getDrawingCache();
        Bitmap bitmap = rootView.getDrawingCache();
        BitmapInput bitmapInput = new BitmapInput("Some bitmap info", bitmap);
        BitmapUtils.saveBitmap(bitmapInput, null);

        return bitmap;
    }

    public void startCamera() {
        try {
            //use standard intent to capture an image
            Intent captureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            //we will handle the returned data in onActivityResult
            startActivityForResult(captureIntent, CAMERA_CAPTURE);
        }catch(ActivityNotFoundException anfe){
            //display an error message
            String errorMessage = "Whoops - your device doesn't support capturing images!";
            Toast toast = Toast.makeText(this, errorMessage, Toast.LENGTH_SHORT);
            toast.show();
        }
    }

    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (resultCode == RESULT_OK) {
            //user is returning from capturing an image using the camera
            if(requestCode == CAMERA_CAPTURE){
                //get the Uri for the captured image
                //picUri = data.getData();
                //Toast toast = Toast.makeText(this, picUri+"", Toast.LENGTH_SHORT);
                //toast.show();
                //get the returned data
                Bundle extras = data.getExtras();
                //get the bitmap
                //cameraBitmap = extras.getParcelable("data");
                //Toast toast1 = Toast.makeText(this, "The Pic= "+cameraBitmap, Toast.LENGTH_SHORT);
                //toast1.show();
                //if (mCustomShapeFragment != null){
                    //     mCustomShapeFragment.customImage.setImageBitmap(cameraBitmap);
                //}
            }
        }
    }

    //Dynamic viewpager loading
    private ArrayList<String> getImages(){
        ArrayList<String> images = new ArrayList<String>();
        images.add("http://dmlab.cs.gsu.edu/dmlabapi/images/SDO/AIA/2k/?wave=171&starttime=2012-02-13T20:10:00");
        images.add("http://dmlab.cs.gsu.edu/dmlabapi/images/SDO/AIA/2k/?wave=131&starttime=2012-02-13T20:10:00");
        images.add("http://dmlab.cs.gsu.edu/dmlabapi/images/SDO/AIA/2k/?wave=193&starttime=2012-02-13T20:10:00");
        images.add("http://dmlab.cs.gsu.edu/dmlabapi/images/SDO/AIA/2k/?wave=211&starttime=2012-02-13T20:10:00");
        images.add("http://dmlab.cs.gsu.edu/dmlabapi/images/SDO/AIA/2k/?wave=304&starttime=2012-02-13T20:10:00");
        images.add("http://dmlab.cs.gsu.edu/dmlabapi/images/SDO/AIA/2k/?wave=335&starttime=2012-02-13T20:10:00");
        return images;
    }

    private void addClassLabel(String classLabel){
        if(radioClassTwo.getVisibility() == View.INVISIBLE){
            classes = classes + 1;
            radioClassTwo.setText(classLabel);
            radioClassTwo.setVisibility(View.VISIBLE);
            radioClassTwo.setChecked(true);
            radioClassTwo.invalidate();
        }else if(radioClassThree.getVisibility() == View.INVISIBLE){
            if(radioClassTwo.getText().toString().equalsIgnoreCase(classLabel)){
                Toast.makeText(SampleDashboardActivity.this, "Class already created!", Toast.LENGTH_LONG).show();
                return;
            }
            classes = classes + 1;
            radioClassThree.setText(classLabel);
            radioClassThree.invalidate();
            radioClassThree.setVisibility(View.VISIBLE);
            radioClassThree.setChecked(true);
            radioClassThree.invalidate();
        }else if(radioClassOne.getVisibility() == View.INVISIBLE){
            if(radioClassTwo.getText().toString().equalsIgnoreCase(classLabel) || radioClassThree.getText().toString().equalsIgnoreCase(classLabel)){
                Toast.makeText(SampleDashboardActivity.this, "Class already created!", Toast.LENGTH_LONG).show();
                return;
            }
            classes = classes + 1;
            radioClassOne.setText(classLabel);
            radioClassOne.setVisibility(View.VISIBLE);
            radioClassOne.setChecked(true);
            radioClassOne.invalidate();
        }
    }

    private void getDialog(){
        final AlertDialog builder = new AlertDialog.Builder(SampleDashboardActivity.this, R.style.LabelDialog)
                .setPositiveButton(R.string.label_create, null)
                .setNegativeButton(R.string.label_decline, null)
                .create();

        final EditText classLabel = new EditText(SampleDashboardActivity.this);
        builder.setView(classLabel);
        builder.setTitle(R.string.lable_dialog_title);
        builder.setMessage("Add a label for classification\n(maximum three classes)");

        builder.setOnShowListener(new DialogInterface.OnShowListener() {
            @Override
            public void onShow(DialogInterface dialog) {
                final Button btnAccept = builder.getButton(AlertDialog.BUTTON_POSITIVE);
                btnAccept.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if(classLabel.getText().toString().isEmpty()) {
                            Toast.makeText(SampleDashboardActivity.this, "Enter CLASS LABEL", Toast.LENGTH_SHORT).show();
                        }
                        else {
                            Log.d(TAG, "CLASS LABEL created: " + classLabel.getText().toString());
                            addClassLabel(classLabel.getText().toString());
                            builder.dismiss();
                        }
                    }
                });

                final Button btnDecline = builder.getButton(DialogInterface.BUTTON_NEGATIVE);
                btnDecline.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Log.d(TAG, "LABEL creation cancelled");
                        builder.dismiss();
                    }
                });
            }
        });

        /* Show the dialog */
        builder.show();

    }


    public Category getCurrentCategory() {
        return mCurrentCategory;
    }

    public void setCurrentSubCategory(String currentSubcategory) {
        this.mCurrentSubcategory = currentSubcategory;
    }


    public void setSharedPrefKey(String preferencesKey){
        mPreferencesKey = preferencesKey;
    }
}
