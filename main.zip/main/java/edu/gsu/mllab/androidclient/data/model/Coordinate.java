package edu.gsu.mllab.androidclient.data.model;

import android.os.Parcel;
import android.os.Parcelable;

import org.json.JSONException;
import org.json.JSONObject;

/**
 * Created by mllab on 3/12/18.
 */

public class Coordinate {
    private Double x;
    private Double y;

    public Coordinate(Double x, Double y) {
        this.x = x;
        this.y = y;
    }

    public JSONObject getJSONObject() {
        JSONObject obj = new JSONObject();
        try {
            obj.put("x", this.x);
            obj.put("y", this.y);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return obj;
    }

    public Double getX(){
        return x;
    }

    public Double getY(){
        return y;
    }
}

