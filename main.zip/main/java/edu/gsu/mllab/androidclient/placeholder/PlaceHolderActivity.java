package edu.gsu.mllab.androidclient.placeholder;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import edu.gsu.mllab.androidclient.R;

public class PlaceHolderActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_place_holder);

        //Intent intent = new Intent(this, LoginActivity.class);
        //startActivity(intent);
    }

}
