package edu.gsu.mllab.androidclient.Utils;

import okhttp3.MediaType;

/**
 * Created by mllab on 1/16/18.
 */

public class Constants {

    // Service end points/URLs
    public static final String TEST_API_BASE_URL = "https://api.github.com/";
    public static final String USER_API_BASE_URL = "https://api.github.com/";
    public static final String LOCAL_HOST = "http://10.0.3.2:8000";//"http://10.0.2.2:8000";//"http://127.0.0.1:8000";//
    public static final MediaType JSON = MediaType.parse("application/json; charset=utf-8");
    public static final String ROOT_FILE_PATH = "/myGroup/myProject/";//"/test_test_info_orig.png";
    public static final int COMPRESSION_RATIO = 80;// compression ratio for saved images

    //For Android Clients

    //Project Identifiers
    public static final String PROJECT_IDENTIFIER_SAMPLE = "sample_mapping_";
    public static final String PROJECT_IDENTIFIER_BRAIN = "brain_mapping_";
    public static final String PROJECT_IDENTIFIER_SOLAR = "solar_mapping_";

    //for custom image views
    public static final int SMOOTHLINE = 2;

    public static final float TOUCH_TOLERANCE = 4;
    public static final float TOUCH_STROKE_WIDTH = 5;


}
