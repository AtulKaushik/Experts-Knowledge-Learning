package edu.gsu.mllab.androidclient.view.recyclerView;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.widget.Toast;

import java.util.Arrays;
import java.util.List;

import edu.gsu.mllab.androidclient.R;
import edu.gsu.mllab.androidclient.data.model.Category;
import edu.gsu.mllab.androidclient.view.adapters.CategoryAdapter;
import edu.gsu.mllab.androidclient.data.model.SubCategory;
import edu.gsu.mllab.androidclient.view.recyclerView.base.root.ExpandableRecyclerAdapter;

public class PlaceHolderExpandableMasterDetailActivity extends AppCompatActivity{

    private CategoryAdapter mAdapter;
    private RecyclerView mRecyclerView;
    private List<Category> mCategories;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_placeholder_expandable_master_detail);

        mCategories = getCategories();

        mRecyclerView = (RecyclerView) findViewById(R.id.placeholder_expandable_master_detail_recyclerview);

        mAdapter = new CategoryAdapter(this, mCategories);

        mAdapter.setExpandCollapseListener(new ExpandableRecyclerAdapter.ExpandCollapseListener() {
            @Override
            public void onListItemExpanded(int position) {
                Category expandedCategory = mCategories.get(position);

                String toastMsg = getResources().getString(R.string.expanded, expandedCategory.getName());
                Toast.makeText(PlaceHolderExpandableMasterDetailActivity.this, toastMsg, Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onListItemCollapsed(int position) {
                Category collapsedCategory = mCategories.get(position);

                String toastMsg = getResources().getString(R.string.collapsed, collapsedCategory.getName());
                Toast.makeText(PlaceHolderExpandableMasterDetailActivity.this, toastMsg, Toast.LENGTH_SHORT).show();
            }
        });

        mRecyclerView.setAdapter(mAdapter);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(this));
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        //save the expanded and collapsed state of items in our Recycler View during our device configuration changes
        mAdapter.onSaveInstanceState(outState);
    }

    @Override
    protected void onRestoreInstanceState(Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);
        //restore the expanded and collapsed state of items in our Recycler View during our device configuration changes
        mAdapter.onRestoreInstanceState(savedInstanceState);
    }

    /*
    Getting dummy data fro categories and subcategories
     */
    private List<Category> getCategories(){
        List<Category> categories;

        SubCategory project_one = new SubCategory("project_one");
        SubCategory project_two  = new SubCategory("project_two");
        SubCategory project_three = new SubCategory("project_three");
        SubCategory project_four  = new SubCategory("project_four");
        SubCategory project_five = new SubCategory("project_five");
        SubCategory project_six = new SubCategory("project_six");
        SubCategory project_seven = new SubCategory("project_seven");
        SubCategory project_eight = new SubCategory("project_eight");
        SubCategory project_nine = new SubCategory("project_nine");
        SubCategory project_ten = new SubCategory("project_ten");
        SubCategory project_eleven = new SubCategory("project_eleven");
        SubCategory project_tweleve = new SubCategory("project_twelve");
        //Populating categories with their subcategories
        Category group_category_one = new Category("ML Group", Arrays.asList(project_one, project_two, project_three, project_four));
        Category group_category_two = new Category("DL Group", Arrays.asList(project_five, project_six, project_seven,project_eight));
        Category group_category_three = new Category("Astrophysics Group", Arrays.asList(project_nine, project_ten, project_eleven,project_tweleve));
        Category group_category_four = new Category("Others", Arrays.asList(project_one, project_five, project_nine,project_tweleve));

        categories = Arrays.asList(group_category_one,  group_category_two, group_category_three,group_category_four);

        return categories;
    }


}