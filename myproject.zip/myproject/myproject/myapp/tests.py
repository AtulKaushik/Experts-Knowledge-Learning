from django.test import TestCase

# Create your tests here.
from django.urls import reverse
from django.urls import resolve
from unittest import skip
from .views import root, home, group_list, group
from .models import Group, Project, Data

class GroupProjectsTests(TestCase):
    def setUp(self):
        self.group = Group.objects.create(name='Django', description='Django group.')
    
#    @skip("skipping")
    def test_group_success_status_code(self):
        url_group = reverse('group', kwargs={'pk': self.group.pk})
        response_group = self.client.get(url_group)
        self.assertEquals(response_group.status_code, 200)
    
#    @skip("skipping")
    def test_group_list_success_status_code(self):
        url_groups = reverse('group_list')
        response_groups = self.client.get(url_groups)
        self.assertEquals(response_groups.status_code, 200)
    
#    @skip("skipping")
    def test_group_list_contains_link_to_group_page(self):
        url_group_list = reverse('group_list')
        response_group_list = self.client.get(url_group_list)
        url_group = reverse('group', kwargs={'pk': self.group.pk})
        response_group = self.client.get(url_group)
        self.assertContains(response_group_list, 'href="{0}"'.format(url_group))

#    @skip("skipping")
    def test_group_view_contains_link_back_to_group_list_page(self):
        group_url = reverse('group', kwargs={'pk': self.group.pk})
        response = self.client.get(group_url)
        groups_homepage_url = reverse('group_list')
        self.assertContains(response, 'href="{0}"'.format(groups_homepage_url))

#    @skip("test_group_listings_view_success_status_code")
    def test_group_view_success_status_code(self):
        url = reverse('group', kwargs={'pk': 1})
        response = self.client.get(url)
        self.assertEquals(response.status_code, 200)
        
#    @skip("test_group_listings_view_not_found_status_code")
    def test_group_listings_view_not_found_status_code(self):
        url = reverse('group', kwargs={'pk': 99})
        response = self.client.get(url)
        self.assertEquals(response.status_code, 404)

#    @skip("test_group_listings_url_resolves_board_topics_view")
    def test_group_url_resolves_group_view(self):
        view = resolve('/groups/1/')
        self.assertEquals(view.func, group)

class RootTests(TestCase):
#    @skip("test_home_view_status_code")
    def test_root_view_status_code(self):
        url = reverse('root')
        response = self.client.get(url)
        self.assertEquals(response.status_code, 200)

#    @skip("test_home_url_resolves_home_view")
    def test_root_url_resolves_root_view(self):
        view = resolve('/')
        self.assertEquals(view.func, root)
        
