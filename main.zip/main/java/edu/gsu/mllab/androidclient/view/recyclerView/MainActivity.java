package edu.gsu.mllab.androidclient.view.recyclerView;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.widget.Toast;
import java.util.Arrays;
import java.util.List;

import edu.gsu.mllab.androidclient.R;
import edu.gsu.mllab.androidclient.data.model.Category;
import edu.gsu.mllab.androidclient.view.adapters.CategoryAdapter;
import edu.gsu.mllab.androidclient.data.model.SubCategory;
import edu.gsu.mllab.androidclient.view.recyclerView.base.root.ExpandableRecyclerAdapter;

public class MainActivity extends AppCompatActivity{

    private CategoryAdapter mAdapter;
    private RecyclerView recyclerView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        SubCategory movie_one = new SubCategory("The Shawshank Redemption");
        SubCategory movie_two  = new SubCategory("The Godfather");
        SubCategory movie_three = new SubCategory("The Dark Knight");
        SubCategory movie_four  = new SubCategory("Schindler's List ");
        SubCategory movie_five = new SubCategory("12 Angry Men ");
        SubCategory movie_six = new SubCategory("Pulp Fiction");
        SubCategory movie_seven = new SubCategory("The Lord of the Rings: The Return of the King");
        SubCategory movie_eight = new SubCategory("The Good, the Bad and the Ugly");
        SubCategory movie_nine = new SubCategory("Fight Club");
        SubCategory movie_ten = new SubCategory("Star Wars: Episode V - The Empire Strikes");
        SubCategory movie_eleven = new SubCategory("Forrest Gump");
        SubCategory movie_tweleve = new SubCategory("Inception");

        Category molvie_category_one = new Category("Drama", Arrays.asList(movie_one, movie_two, movie_three, movie_four));
        Category molvie_category_two = new Category("Action", Arrays.asList(movie_five, movie_six, movie_seven,movie_eight));
        Category molvie_category_three = new Category("History", Arrays.asList(movie_nine, movie_ten, movie_eleven,movie_tweleve));
        Category molvie_category_four = new Category("Thriller", Arrays.asList(movie_one, movie_five, movie_nine,movie_tweleve));

        final List<Category> movieCategories = Arrays.asList(molvie_category_one,  molvie_category_two, molvie_category_three,molvie_category_four);

        recyclerView = (RecyclerView) findViewById(R.id.recyclerview);
        mAdapter = new CategoryAdapter(this, movieCategories);
        mAdapter.setExpandCollapseListener(new ExpandableRecyclerAdapter.ExpandCollapseListener() {
            @Override
            public void onListItemExpanded(int position) {
                Category expandedCategory = movieCategories.get(position);

                String toastMsg = getResources().getString(R.string.expanded, expandedCategory.getName());
                Toast.makeText(MainActivity.this,
                        toastMsg,
                        Toast.LENGTH_SHORT)
                        .show();
            }

            @Override
            public void onListItemCollapsed(int position) {
                Category collapsedCategory = movieCategories.get(position);

                String toastMsg = getResources().getString(R.string.collapsed, collapsedCategory.getName());
                Toast.makeText(MainActivity.this,
                        toastMsg,
                        Toast.LENGTH_SHORT)
                        .show();
            }
        });

        recyclerView.setAdapter(mAdapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        mAdapter.onSaveInstanceState(outState);
    }

    @Override
    protected void onRestoreInstanceState(Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);
        mAdapter.onRestoreInstanceState(savedInstanceState);
    }
}