package edu.gsu.mllab.androidclient.activity.groups.projects.brain;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PorterDuff;
import android.support.v7.widget.AppCompatImageView;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

import edu.gsu.mllab.androidclient.data.model.Coordinate;

import static android.content.Context.MODE_PRIVATE;


/**
 * Created by mllab on 3/1/18.
 */

public class BrainCustomImageView extends AppCompatImageView {

    private static String TAG = BrainCustomImageView.class.getSimpleName();

    public static final int SMOOTHLINE = 2;

    public static final float TOUCH_TOLERANCE = 4;
    public static final float TOUCH_STROKE_WIDTH = 5;

    public int mCurrentShape;

    protected Path mPath;
    //protected CustomPath mPath;
    protected ArrayList<Coordinate> coordinates;
    protected Coordinate coordinate;

    protected Paint mPaint;
    protected Paint mPaintFinal;
    protected Paint mRedrawPaint;

    protected Bitmap mBitmap;
    protected Canvas mCanvas;

    private SharedPreferences  mPreferences;
    SharedPreferences.Editor mPrefsEditor;
    private String  mPreferencesKey;

    /**
     * Indicates if you are drawing
     */
    protected boolean isDrawing = false;

    /**
     * Indicates if the drawing is ended
     */
    protected boolean isDrawingEnded = false;

    //flag to enable/disable drawing
    protected static boolean drawingEnabled = false;


    protected float mStartX;
    protected float mStartY;

    protected float mx;
    protected float my;

    public BrainCustomImageView(Context context) {
        super(context);
        // TODO Auto-generated constructor stub
        setBackgroundColor(Color.WHITE);
        init();

    }

    public BrainCustomImageView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    public BrainCustomImageView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();
    }

    @Override
    protected void onLayout(boolean changed, int l, int t, int r, int b) {

    }

    //private static final String COORDINATES_REPO = "cooordiantes_repo3";


    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        mBitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        mCanvas = new Canvas(mBitmap);

        Log.i(TAG,"creating/retriving Shared pref "+ mPreferencesKey);
        //TODO: Getting prefs key, as of now image resorceId. See BrainPageFragment for more info.
        mPreferences = getContext().getSharedPreferences(mPreferencesKey, MODE_PRIVATE);
        mPrefsEditor = mPreferences.edit();

        //coordinates = (coordinates == null)? new ArrayList<Coordinate>():coordinates;
        //coordinates.clear();

        //TODO: This is the logic to draw any previosly saved path coordinates
        //This method will be called during each initialization
        //coordinates = new ArrayList<Coordinate>();
        //ArrayList<Coordinate> savedCoordinates = retrievePathCoordinates(); //method may return null, if there's no saved path coordinates
        //if(savedCoordinates != null && !savedCoordinates.isEmpty()){
          //  coordinates.addAll(retrievePathCoordinates());
        //}

        coordinates = retrievePathCoordinates(); //method may return null, if there's no saved path coordinates

        //TODO: This is the logic to draw any previosly saved path coordinates
        //This method will be called several times during the initialization
        //coordinates = retrievePathCoordinates(); //method may return null, if there's no saved path coordinates
        //Log.i(TAG, "Saved Path Coordinates = "+!coordinates.isEmpty());
        if(coordinates != null && !coordinates.isEmpty()){
            Log.i(TAG, "retrieving Saved PathCoordinates");
            //mPath.reset();
            for (Coordinate coordinate : coordinates){
               mPath.moveTo(coordinate.getX().floatValue(), coordinate.getY().floatValue());
                mPath.lineTo(coordinate.getX().floatValue(), coordinate.getY().floatValue());
            }

            mCanvas.drawPath(mPath, mRedrawPaint);
            mPath.reset();
            invalidate();
        }
    }


    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        canvas.drawBitmap(mBitmap, 0, 0, mPaint);
    }




    protected void init() {
        mPath = new Path();

        // Setup paint and attributes for any moving action
        mPaint = new Paint(Paint.DITHER_FLAG);
        mPaint.setAntiAlias(true);
        mPaint.setDither(true);
        mPaint.setColor(getContext().getResources().getColor(android.R.color.holo_green_dark));
        mPaint.setStyle(Paint.Style.STROKE);
        mPaint.setStrokeJoin(Paint.Join.ROUND);
        mPaint.setStrokeCap(Paint.Cap.ROUND);
        mPaint.setStrokeWidth(TOUCH_STROKE_WIDTH);

        // Setup paint and attributes for any up action
        mPaintFinal = new Paint(Paint.DITHER_FLAG);
        mPaintFinal.setAntiAlias(true);
        mPaintFinal.setDither(true);
        mPaintFinal.setColor(getContext().getResources().getColor(android.R.color.holo_blue_dark));
        mPaintFinal.setStyle(Paint.Style.STROKE);
        mPaintFinal.setStrokeJoin(Paint.Join.ROUND);
        mPaintFinal.setStrokeCap(Paint.Cap.ROUND);
        mPaintFinal.setStrokeWidth(TOUCH_STROKE_WIDTH);

        // Setup paint and attributes for any redrawing
        mRedrawPaint = new Paint(Paint.DITHER_FLAG);
        mRedrawPaint.setStyle(Paint.Style.FILL);
        mRedrawPaint.setStyle(Paint.Style.STROKE);
        mRedrawPaint.setStrokeWidth(12);
        mRedrawPaint.setColor(getContext().getResources().getColor(android.R.color.holo_orange_light));
        mRedrawPaint.setStrokeJoin(Paint.Join.ROUND);
        mRedrawPaint.setStrokeCap(Paint.Cap.ROUND);

    }

    public void reset() {
        mPath = new Path();
        //mPath = new CustomPath();
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        //ACTION_MOVE = 2, ACTION_UP = 1
        Log.i(TAG,"onTouchEvent = "+event.getAction());
        if(drawingEnabled){
            mx = event.getX();
            my = event.getY();

            switch (mCurrentShape) {
                case SMOOTHLINE:
                    onTouchEventSmoothLine(event);
                    break;
            }
            return true;
        }
        return false;
    }


    //------------------------------------------------------------------
    // Smooth Line / Freehand
    //------------------------------------------------------------------


    private void onTouchEventSmoothLine(MotionEvent event) {

        coordinates = (coordinates == null)? new ArrayList<Coordinate>():coordinates;
        //coordinates.clear(); //Removing any previously saved coordinates
        coordinates.add(new Coordinate((double)mx, (double)my));

        switch (event.getAction()) {
            case MotionEvent.ACTION_DOWN:

                isDrawing = true;
                mStartX = mx;
                mStartY = my;

                mPath.reset();
                mPath.moveTo(mx, my);
                Log.i("::ACTION_DOWN::", mStartX +" // " +mStartY);
                invalidate();
                break;
            case MotionEvent.ACTION_MOVE:

                float dx = Math.abs(mx - mStartX);
                float dy = Math.abs(my - mStartY);
                if (dx >= TOUCH_TOLERANCE || dy >= TOUCH_TOLERANCE) {
                    mPath.quadTo(mStartX, mStartY, (mx + mStartX) / 2, (my + mStartY) / 2);
                    mStartX = mx;
                    mStartY = my;
                }
                mCanvas.drawPath(mPath, mPaint);
                Log.i(TAG,"ACTION_MOVE::"+ mStartX +" // " +mStartY);
                invalidate();
                break;
            case MotionEvent.ACTION_UP:
                isDrawing = false;
                mPath.lineTo(mStartX, mStartY);
                Log.i(TAG,"ACTION_UP::"+ mStartX +" // " +mStartY);
                mCanvas.drawPath(mPath, mPaintFinal);
                mPath.reset();
                invalidate();
                //TODO: You can call saveCustomPath(coordinates); if you wish to save every path on each draw
                //saveCustomPath(coordinates);
                //saveCustomPath();
                //coordinates.clear();
                break;
        }
    }


    public void clearCanvas(){
        mPath.reset();
        mCanvas.drawColor(Color.TRANSPARENT, PorterDuff.Mode.CLEAR);
        invalidate();
    }

    public void setDrawingEnabled(boolean drawingEnabled) {
        this.drawingEnabled = drawingEnabled;
    }

    public boolean isDrawingEnabled() {
        return drawingEnabled;
    }


    public void saveCustomPath(){
        if (coordinates == null ){
            Log.i(TAG, "no Path Coordinates to save: Coordinates null");
            return;
        }

        ArrayList<Coordinate> previouslySavedCoordinates;// = new ArrayList<Coordinate>();
        previouslySavedCoordinates = retrievePathCoordinates();
        if(previouslySavedCoordinates != null && !previouslySavedCoordinates.isEmpty()){
            Log.i(TAG,"adding previously saved coordinates");
            coordinates.addAll(previouslySavedCoordinates);
        }

        //TODO: Hashset doesn't maintain the order, therefore redrwaing points will clutter the image. Fix this on a later stage.
        Set<String> set= new HashSet<String>();
        for (int i = 0; i < coordinates.size(); i++) {
            set.add(coordinates.get(i).getJSONObject().toString());
        }

        mPrefsEditor.putStringSet(mPreferencesKey, set);
        mPrefsEditor.commit();
        Log.i(TAG,"savedCustomPath = "+ set.toString());
        coordinates.clear();
    }

    private ArrayList<Coordinate> retrievePathCoordinates(){
        if(mPreferencesKey == null) return null;
            ArrayList<Coordinate> savedCoordinates = new ArrayList<Coordinate>();
            Set<String> set = mPreferences.getStringSet(mPreferencesKey, null);
            if (set != null) {
                for (String s : set) {
                    try {
                        JSONObject jsonObject = new JSONObject(s);
                        Double x = jsonObject.getDouble("x");
                        Double y = jsonObject.getDouble("y");
                        Coordinate coordinate = new Coordinate(x, y);

                        savedCoordinates.add(coordinate);

                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
                Log.i(TAG, "retrieving saved CustomPath = "+ set.toString());
                return savedCoordinates;
            }
        return null;
    }

    public void clearCustomPath(){
        mPrefsEditor.putStringSet(mPreferencesKey, null);
        mPrefsEditor.commit();
        //TODO: refresh view here to clear saved coordiantes
        mPath.reset();
        mCanvas.drawColor(Color.TRANSPARENT, PorterDuff.Mode.CLEAR);
        invalidate();
    }

    public void setPreferencesKey(String preferencesKey){
        Log.i(TAG, "Setting shared pref key = "+ preferencesKey);
        mPreferencesKey = preferencesKey;
    }

}