from django.shortcuts import render
from django.shortcuts import get_list_or_404, get_object_or_404

# Create your views here.
from django.http import HttpResponse, Http404
from .models import Group, Project, Data

#This method is for rendering root api page
def root(request):
    #groups = Group.objects.all()
    #return render(request,'groups.html',{'groups':groups})
    return render(request,'welcome.html')
    #return HttpResponse('Welcome to the project!!')

#This will be the dashboard with groups
def group_list(request):
#   groups = Group.objects.all()
    groups = get_list_or_404(Group)
    return render(request,'group_list.html',{'groups':groups})

def group(request, pk):
    group = get_object_or_404(Group, pk=pk)
    projects = get_list_or_404(Project, pk=pk)#Project.objects.all()
    return render(request, 'group.html', {'group': group, 'projects': projects})
#    try:
#        group = Group.objects.get(pk=pk)
#    except Group.DoesNotExist:
#        raise Http404
#    return render(request, 'projects.html', {'group': group}) 

#This will be the dashboard for a project
def project(request, pk):
    project = get_object_or_404(Project, pk=pk)
    datas = get_list_or_404(Data)
    return render(request,'project.html',{'project':project, 'datas': datas })

#This will be the homepage (this is adopted from blogs)
def home(request):
    groups = Group.objects.all()
    return render(request,'home.html',{'groups':groups})


#def home(request):
#    groups = Group.objects.all()
#    groups_names = list()

#    for group in groups:
#        groups_names.append(group.name)

#    response_html = '<br>'.join(groups_names)

#    return HttpResponse(response_html)
