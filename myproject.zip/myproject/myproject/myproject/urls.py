"""myproject URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/2.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.conf.urls import url
from django.contrib import admin

from myapp import views
# Put more restrictive urls first, otherwise they will never be invoked if more general urls come before restrictive ones
urlpatterns = [
    # root url
    url(r'^$', views.root, name='root'),
    #url(r'^user/(?P<username>[\w.@+-]+)/$', views.home, name='user_profile'),
    #for getting a group by <id> or <pk> and associated projects (list)
    url(r'^groups/(?P<pk>\d+)/$', views.group, name='group'),
    # for getting list of groups
    url(r'^groups/$', views.group_list, name='group_list'),
    #for getting project in a group by id 
    url(r'^projects/(?P<pk>\d+)/$', views.project, name='project'),
    #url(r'^about/$', views.about, name='about'),
    url(r'^home/$', views.home, name='home'),
    #for managing admin console
    url(r'^admin/', admin.site.urls),
]

#from django.contrib import admin
#from django.urls import path

#urlpatterns = [
#    path('admin/', admin.site.urls),
#]
