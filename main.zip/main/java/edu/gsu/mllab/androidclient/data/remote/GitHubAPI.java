package edu.gsu.mllab.androidclient.data.remote;

import java.util.List;

import edu.gsu.mllab.androidclient.data.model.GitHubRepo;
import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Path;

/**
 * Created by mllab on 1/16/18.
 */

public interface GitHubAPI {
    @GET("/users/{user}/repos")
        Call<List<GitHubRepo>> reposForUser(@Path("user") String user);
}