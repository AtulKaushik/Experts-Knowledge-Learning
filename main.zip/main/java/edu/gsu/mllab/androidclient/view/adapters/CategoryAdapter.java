package edu.gsu.mllab.androidclient.view.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import java.util.List;

import edu.gsu.mllab.androidclient.R;
import edu.gsu.mllab.androidclient.data.model.Category;
import edu.gsu.mllab.androidclient.data.model.SubCategory;
import edu.gsu.mllab.androidclient.view.viewholders.CategoryViewHolder;
import edu.gsu.mllab.androidclient.view.viewholders.SubCategoryViewHolder;
import edu.gsu.mllab.androidclient.view.recyclerView.base.root.ExpandableRecyclerAdapter;
import edu.gsu.mllab.androidclient.view.recyclerView.base.root.ParentListItem;

public class CategoryAdapter extends ExpandableRecyclerAdapter<CategoryViewHolder, SubCategoryViewHolder> {

    private LayoutInflater mInflator;

    public CategoryAdapter(Context context, List<? extends ParentListItem> parentItemList) {
        super(parentItemList);
        mInflator = LayoutInflater.from(context);
    }

    @Override
    public CategoryViewHolder onCreateParentViewHolder(ViewGroup parentViewGroup) {
        View categoryView = mInflator.inflate(R.layout.category_view, parentViewGroup, false);
        return new CategoryViewHolder(categoryView);
    }

    @Override
    public SubCategoryViewHolder onCreateChildViewHolder(ViewGroup childViewGroup) {
        View subcategoryView = mInflator.inflate(R.layout.subcategory_view, childViewGroup, false);
        return new SubCategoryViewHolder(subcategoryView);
    }

    @Override
    public void onBindParentViewHolder(CategoryViewHolder categoryViewHolder, int position, ParentListItem parentListItem) {
        Category category = (Category) parentListItem;
        categoryViewHolder.bind(category);
    }

    @Override
    public void onBindChildViewHolder(SubCategoryViewHolder subCategoryViewHolder, int position, Object childListItem) {
        SubCategory subCategory = (SubCategory) childListItem;
        subCategoryViewHolder.bind(subCategory);
    }
}
