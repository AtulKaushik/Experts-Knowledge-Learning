package edu.gsu.mllab.androidclient.bitmap;

import android.graphics.Bitmap;

/**
 * This is a callback object which could be passed/invoked from async task
 */
public interface BitmapCallback {

    public void onStarted();
    public void onSaved(Bitmap bitmap);
    public void onOutOfMemoryError();
    public void onError();
}
